/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	start up Models-3 I/O API (wrapper around Fortran-binding
C	routine INIT3()
C	
C
C PRECONDITIONS:
C
C CALLS:
C	Fortran I/O API's INIT3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  WIN32 stuff
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */
#define INIT3 init3_
#elif defined(__hpux) || defined(_AIX)
#define INIT3 init3
#endif


#if defined(INIT3) || defined(_WIN32) || defined(_CRAY)

    extern int INIT3( void ) ;

int init3c( void )
    {
    return INIT3() ;
    }


#else

#error   "Error compiling init3c():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

