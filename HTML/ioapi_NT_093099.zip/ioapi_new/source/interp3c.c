/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Time-interpolates specified variable "vname" from file with 
C 	logical name "fname" from "buffer".
C	C wrapper around I/O API Fortran binding routine INTERP3().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's INTERP3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  WIN32 stuff
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */
#define INTERP3 interp3_
#elif defined(__hpux) || defined(_AIX)
#define INTERP3 interp3
#endif


#if defined(INTERP3)

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int INTERP3( const char  * fname ,
                        const char  * vname ,
                        const char  * cname ,
                        int         * jdate ,
                        int         * jtime ,
                        int         * bsize ,
                        FREAL       * buffer,
                        int           fnamelen ,
                        int           vnamelen ,
                        int           cnamelen ) ;

int interp3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )

    {       /*  begin body of interp3c() */

    return INTERP3(  fname , 
                     vname , 
                     cname , 
                   & jdate , 
                   & jtime , 
                   & bsize , 
                     buffer,
                     strlen( fname ) , 
                     strlen( vname ) , 
                     strlen( cname ) ) ;

    }       /*  end body of interp3c()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32-TARGETED interp3c(): **/

#elif defined(_WIN32)

    extern int INTERP3( const char  * fname ,
                        int           fnamelen ,
                        const char  * vname ,
                        int           vnamelen ,
                        const char  * cname ,
                        int           cnamelen ,
                        int         * jdate ,
                        int         * jtime ,
                        int         * bsize ,
                        FREAL       * buffer );

int interp3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )

    {       /*  begin body of interp3c() */

    return INTERP3(  fname , 
                     strlen( fname ) , 
                     vname , 
                     strlen( vname ) ,
                     cname , 
                     strlen( cname ) ,
                   & jdate , 
                   & jtime , 
                   & bsize , 
                     buffer);

    }       /*  end body of interp3c()  */

                	/** END  CASE OF WIN32 F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED interp3c(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int INTERP3( const _fcd     fname ,
                        const _fcd     vname ,
                        const _fcd     cname ,
                        const  int   * jdate ,
                        const  int   * jtime ,
                        const  int   * bsize ,
                        FREAL        * buffer ) ;

int interp3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )
 
    {       /*  begin body of interp3c() */
    
    _fcd  file ;
    _fcd  vble ;
    _fcd  caller ;
    
    file   = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble   = _cptofcd( (char *)vname, strlen( vname ) ) ;
    caller = _cptofcd( (char *)cname, strlen( cname ) ) ;

    return _btol( INTERP3(  file  , 
                            vble  , 
                            caller  , 
                          & jdate , 
                          & jtime ,
                          & bsize ,
                            buffer ) ) ; 
                     
    }       /*  end body of interp3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED interp3c(): **/

#else

#error   "Error compiling interp3c():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

