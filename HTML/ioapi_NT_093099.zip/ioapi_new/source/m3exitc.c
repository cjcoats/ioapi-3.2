/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Generate simple error messages for Models-3 core;
C	shut down I/O API via SHUT3() and terminate program 
C       execution via exit( errstat )
C
C PRECONDITIONS:
C	JDATE:JTIME represented as YYYYDDD:HHMMSS
C
C CALLS:
C	Fortran M3EXIT()
C
C REVISION HISTORY:
C	Prototype 4/95 by CJC
C	Version   8/99 by CJC:  Win32, OpenMP
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)
#define M3EXIT m3exit_
#elif defined(__hpux) || defined(_AIX)
#define M3EXIT m3exit
#endif

#if defined(M3EXIT)

    extern void M3EXIT( const char * caller ,
                        const int  * jdate ,
                        const int  * jtime ,
                        const char * errtxt ,
                        const int  * errstat ,
                        int          clen ,
                        int          elen ) ;

void m3exitc( const char * caller ,
              int          jdate ,
              int          jtime ,
              const char * errtxt ,
              int          errstat )

    {       /*  begin body of m3exitc() */

    M3EXIT( caller, &jdate, &jtime, errtxt, &errstat,
           strlen( caller ) , strlen( errtxt ) ) ;
    return ;

    }       /*  end body of m3exitc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32 m3exitc(): **/

#elif defined(_WIN32)

    extern void M3EXIT( const char * caller ,
                        int          clen ,
                        const int  * jdate ,
                        const int  * jtime ,
                        const char * errtxt ,
                        int          elen ,
                        const int  * errstat );

void m3exitc( const char * caller ,
              int          jdate ,
              int          jtime ,
              const char * errtxt ,
              int          errstat )

    {       /*  begin body of m3exitc() */

    M3EXIT( caller, strlen( caller ), &jdate, &jtime,
            errtxt, strlen( errtxt ), &errstat );

    return ;

    }       /*  end body of m3exitc ()  */

                	/** END  CASE OF WIN32 **/
                	/** NEXT CASE:  CRAY CF77-TARGETED m3exitc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern void M3EXIT( const _fcd   caller , 
                        const  int * jdate  ,
                        const  int * jtime  ,
                        const _fcd   errtxt ,
                        const  int * errstat ) ;

void m3exitc( const char * caller ,
              int          jdate  ,
              int          jtime  ,
              const char * errtxt , 
              int          errstat )

    {       /*  begin body of m3exitc() */
    
    _fcd  cname ;
    _fcd  etext ;
    
    cname = _cptofcd( (char *)caller, strlen( caller ) ) ;
    etext = _cptofcd( (char *)errtxt, strlen( errtxt ) ) ;

    M3EXIT( cname, &jdate, &jtime, etext, &errstat ) ;
                     
    }       /*  end body of m3exitc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED m3exitc(): **/

#else

#error   "Error compiling m3exitc():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

