/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	reads specified layer of variable "vname" from file with 
C 	logical name "fname" and puts it into "buffer".
C	C wrapper around I/O API Fortran binding routine READ4D().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's READ4D()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */

#define READ4D read4d_

#elif defined(__hpux) || defined(_AIX)

#define READ4D read4d

#endif


#if defined(READ4D)

    extern int READ4D( const char * fname ,
                       const char * vname ,
                       int        * layer ,
                       int        * jdate ,
                       int        * jtime ,
                       int        * tstep ,
                       int        * nrecs ,
                       void       * buffer,
                       int          fnamelen ,
                       int          vnamelen ) ;

int read4dc( const char * fname ,
             const char * vname ,
             int          layer ,
             int          jdate ,
             int          jtime ,
             int          tstep ,
             int          nrecs ,
             void       * buffer )

    {       /*  begin body of read4dc() */

    return READ4D(  fname , 
                    vname , 
                  & layer ,
                  & jdate , 
                  & jtime , 
                  & tstep , 
                  & nrecs , 
                    buffer,
                    strlen( fname ) , 
                    strlen( vname ) ) ;

    }       /*  end body of read4dc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED read4dc() **/
                	/** NEXT CASE:               WIN32 read4dc(): **/

#elif defined(_WIN32)

    extern int READ4D( const char * fname ,
                       int          fnamelen ,
                       const char * vname ,
                       int          vnamelen ,
                       int        * layer ,
                       int        * jdate ,
                       int        * jtime ,
                       int        * tstep ,
                       int        * nrecs ,
                       void       * buffer );

int read4dc( const char * fname ,
             const char * vname ,
             int          layer ,
             int          jdate ,
             int          jtime ,
             int          tstep ,
             int          nrecs ,
             void       * buffer )

    {       /*  begin body of read4dc() */

    return READ4D(  fname , 
                    strlen( fname ) , 
                    vname , 
                    strlen( vname ) ,
                  & layer ,
                  & jdate , 
                  & jtime , 
                  & tstep , 
                  & nrecs , 
                    buffer );

    }       /*  end body of read4dc ()  */

                	/** END  CASE OF WIN32 read4dc() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED read4dc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int READ4D( const _fcd    fname ,
                       const _fcd    vname ,
                       const  int  * layer ,
                       const  int  * jdate ,
                       const  int  * jtime ,
                       const  int  * tstep ,
                       const  int  * nrecs ,
                       void        * buffer ) ;

int read4dc( const char * fname ,
             const char * vname ,
             int          layer ,
             int          jdate ,
             int          jtime ,
             int          tstep ,
             int          nrecs ,
                   void * buffer )
 
    {       /*  begin body of read4dc() */
    
    _fcd  file ;
    _fcd  vble ;
    
    file = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble = _cptofcd( (char *)vname, strlen( vname ) ) ;

    return _btol( READ4D(  file , 
                           vble , 
                         & layer,
                         & jdate, 
                         & jtime,
                         & tstep,
                         & nrecs,
                           buffer ) ) ; 
                     
    }       /*  end body of read4dc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED read4dc(): **/

#else

#error   "Error compiling read4dc():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

