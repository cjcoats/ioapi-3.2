/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	Determines the month (1...12) and day of the month (1..31)
	for the Julian date YYYYDDD that is input

PRECONDITIONS

CALLS
	none

REVISION HISTORY
	prototype  3/95 by CJC
                    
**************************************************************************/

#include  "iodecl3.h"


void daymonc ( int jdate, int  *month, int  *mday )
    {
    int  year, day, j, k ;
     
    year = jdate / 1000 ;
    day  = jdate % 1000 ;
    k = ( year %   4 ) ? 365 :
        ( year % 100 ) ? 366 :
        ( year % 400 ) ? 365 : 366 ;
    j = ( day + 305 ) % k ;
    j = ( j % 153 ) / 61  +  2 * ( j / 153 )  +  j ;
    
    *month = ( j / 31 + 2 ) % 12  +  1 ;
    *mday  =   j % 31             +  1 ;

    }       /*  end body of daymonc()  */

