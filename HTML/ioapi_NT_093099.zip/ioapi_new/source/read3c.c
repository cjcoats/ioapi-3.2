/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	reads specified layer of variable "vname" from file with 
C 	logical name "fname" and puts it into "buffer".
C	C wrapper around I/O API Fortran binding routine READ3().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's READ3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"

#if FLDMN && !defined(_WIN32)

#define READ3 read3_

#elif defined(__hpux) || defined(_AIX)

#define READ3 read3

#endif


#if defined(READ3)

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int READ3( const char * fname ,
                      const char * vname ,
                      int        * layer ,
                      int        * jdate ,
                      int        * jtime ,
                      void       * buffer,
                      int          fnamelen ,
                      int          vnamelen ) ;

int read3c( const char * fname ,
            const char * vname ,
            int          layer ,
            int          jdate ,
            int          jtime ,
            void       * buffer )

    {       /*  begin body of read3c() */

    return READ3(  fname , 
                   vname , 
                 & layer ,
                 & jdate , 
                 & jtime , 
                   buffer,
                   strlen( fname ) , 
                   strlen( vname ) ) ;

    }       /*  end body of read3c ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32 read3c(): **/

#elif defined(_WIN32)

    extern int READ3( const char * fname ,
                      int          fnamelen ,
                      const char * vname ,
                      int          vnamelen ,
                      int        * layer ,
                      int        * jdate ,
                      int        * jtime ,
                      void       * buffer );

int read3c( const char * fname ,
            const char * vname ,
            int          layer ,
            int          jdate ,
            int          jtime ,
            void       * buffer )

    {       /*  begin body of read3c() */

    return READ3(  fname , 
                   strlen( fname ) , 
                   vname , 
                   strlen( vname ) ,
                 & layer ,
                 & jdate , 
                 & jtime , 
                   buffer );

    }       /*  end body of read3c ()  */

                	/** END  CASE OF WIN32 read3c() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED read3c(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int READ3( const _fcd    fname ,
                      const _fcd    vname ,
                      const  int  * layer ,
                      const  int  * jdate ,
                      const  int  * jtime ,
                      void        * buffer ) ;

int read3c( const char * fname ,
            const char * vname ,
            int          layer ,
            int          jdate ,
            int          jtime ,
                  void * buffer )
 
    {       /*  begin body of read3c() */
    
    _fcd  file ;
    _fcd  vble ;
    
    file = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble = _cptofcd( (char *)vname, strlen( vname ) ) ;

    return _btol( READ3(  file , 
                          vble , 
                        & layer,
                        & jdate, 
                        & jtime,
                          buffer ) ) ; 
                     
    }       /*  end body of read3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED read3c(): **/

#else

#error   "Error compiling read3c():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

