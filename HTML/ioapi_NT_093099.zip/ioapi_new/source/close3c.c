/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Close Models-3 file with the specified logical name.  
C	Wrapper around I/O API Fortran-binding routine CLOSE3()
C
C PRECONDITIONS:
C	FNAME already opened by CLOSE3() or close3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's CLOSE3()
C
C REVISION HISTORY:
C	Prototype 8/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#ifndef _WIN32			/* JEB */
#if FLDMN
#define CLOSE3 close3_
#elif  defined(__hpux) || defined(_AIX)
#define CLOSE3 close3
#endif
#endif					/* JEB */


#if  defined(CLOSE3) || defined(_WIN32)

    extern int CLOSE3( const char * fname,
                       int          namlen ) ;
                     
int close3c( const char          * fname )

    {       /*  begin body of close3c() */
    return CLOSE3(  fname , (int) strlen( fname ) ) ;
    }       /*  end body of close3c ()  */

                	/** END  CASE OF Feldman-ish close3c() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED close3c(): **/


#elif  defined(_CRAY)

#include <fortran.h>

    extern int CLOSE3( const _fcd   fname ) ;

int close3c( const char          * fname )

    {       /*  begin body of close3c() */
    
    _fcd  file ;

    file = _cptofcd( (char *)fname, (int) strlen( fname ) ) ;
    return _btol( CLOSE3( file ) ) ;
                     
    }       /*  end body of close3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED close3c(): **/

#else

#error   "Error compiling close3c():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

