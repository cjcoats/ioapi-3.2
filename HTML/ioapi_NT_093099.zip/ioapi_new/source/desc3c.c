/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	returns file descriptions for open M3 files.
C	C wrapper around Fortran-binding routine DESC3().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C
C CALLS:
C	Fortran I/O API's DESC3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)   /* JEB */

#define DESC3 desc3_

#elif defined(__hpux) || defined(_AIX)

#define DESC3 desc3

#endif


#if defined(DESC3) || defined(_WIN32 )

    extern int DESC3( const char *fname ,
                      const int   fnamelen ) ;
#if defined(_WIN32)				/* JEB */
	extern IOAPI_Bdesc3 BDESC3; /* JEB */
    extern IOAPI_Cdesc3 CDESC3; /* JEB */
#else							/* JEB */
    extern IOAPI_Bdesc3 bdesc3_ ;
    extern IOAPI_Cdesc3 cdesc3_ ;
#endif							/* JEB */

int desc3c( const char    * fname ,
            IOAPI_Bdesc3  * bdesc ,
            IOAPI_Cdesc3  * cdesc )

    {       /*  begin body of desc3c() */

    if( ! bdesc ) return( 0 ) ;
    if( ! cdesc ) return( 0 ) ;

    if ( DESC3( fname , strlen( fname ) ) )
        {
#if defined(_WIN32)			/* JEB */
        memcpy( (void*) bdesc, (void*) &BDESC3, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) cdesc, (void*) &CDESC3, sizeof( IOAPI_Cdesc3 ) ) ;
#else						/* JEB */
        memcpy( (void*) bdesc, (void*) &bdesc3_, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) cdesc, (void*) &cdesc3_, sizeof( IOAPI_Cdesc3 ) ) ;
#endif						/* JEB */
        return 1 ;
        }
    else{
        return 0 ;
        }

    }       /*  end body of desc3c ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED desc3c(): **/


#elif  defined(_CRAY)


#include <fortran.h>

    extern int DESC3( const _fcd   fname ) ;

    IOAPI_Bdesc3  BDESC3 ;
    IOAPI_Cdesc3  CDESC3 ;


int desc3c( const char    * fname ,
            IOAPI_Bdesc3  * bdesc ,
            IOAPI_Cdesc3  * cdesc )

    {       /*  begin body of desc3c() */
    
    _fcd  file ;
    
    if( ! bdesc ) return( 0 ) ;
    if( ! cdesc ) return( 0 ) ;

    file = _cptofcd( (char *)fname, strlen( fname ) ) ;

    if ( _btol( DESC3( file ) ) )
        {
        memcpy( (void*) bdesc, (void*) &BDESC3, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) cdesc, (void*) &CDESC3, sizeof( IOAPI_Cdesc3 ) ) ;
        return 1 ;
        }
    else{
        return 0 ;
        }
                     
    }       /*  end body of desc3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED desc3c(): **/

#else

#error   "Error compiling desc3c():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

