/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Generate simple error messages for Models-3 core;
C	terminate program execution iff FATAL.
C
C PRECONDITIONS:
C	JDATE:JTIME represented as YYYYDDD:HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 4/95 by CJC
C	Version   8/99 by CJC -- FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */
#define M3MESG m3mesg_
#elif defined(__hpux) || defined(_AIX)
#define M3MESG m3mesg
#endif


#if defined(M3MESG) || defined(_WIN32)


    extern void M3MESG( const char * message ,
                        int          mlen ) ;

void m3mesgc( const char * message )
    {       /*  begin body of m3mesgc() */

    M3MESG( message, strlen( message ) ) ;
    return ;

    }       /*  end body of m3mesgc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32 m3mesgc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern void M3MESG( const _fcd   message ) ;

void m3mesgc( const char * message )

    {       /*  begin body of m3mesgc() */
    
    _fcd  mtext ;
    
    mtext = _cptofcd( (char *)message, strlen( message ) ) ;

    M3MESG( mtext ) ;
    return ;
                     
    }       /*  end body of m3mesgc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED m3mesgc(): **/

#else

#error   "Error compiling m3mesgc():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

