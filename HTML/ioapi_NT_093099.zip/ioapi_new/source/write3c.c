/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Writes specified variable "vname" to file with 
C 	logical name "fname" from "buffer".
C	C wrapper around I/O API Fortran binding routine WRITE3().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's WRITE3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/
#if FLDMN && !defined(_WIN32) /* JEB */      /*  see parms3.h  */

#define WRITE3 write3_

#elif defined(__hpux) || defined(_AIX)

#define WRITE3 write3

#endif


#if defined(WRITE3)

    extern int WRITE3( const char *fname ,
                       const char *vname ,
                       int        *jdate ,
                       int        *jtime ,
                       const void *buffer,
                       int         fnamelen ,
                       int         vnamelen ) ;

int write3c( const char * fname ,
             const char * vname ,
             int          jdate ,
             int          jtime ,
             const void * buffer )

    {       /*  begin body of write3c() */

    return WRITE3(  fname , 
                    vname , 
                  & jdate , 
                  & jtime , 
                    buffer,
                    strlen( fname ) , 
                    strlen( vname ) ) ;

    }       /*  end body of write3c ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32 write3c(): **/

#elif  defined(_WIN32)

    extern int WRITE3( const char *fname    ,
                       int         fnamelen ,
                       const char *vname    ,
                       int         vnamelen ,
                       int        *jdate    ,
                       int        *jtime    ,
                       const void *buffer ) ;

int write3c( const char * fname ,
             const char * vname ,
             int          jdate ,
             int          jtime ,
             const void * buffer )

    {       /*  begin body of write3c() */

    return WRITE3(  fname           , 
                    strlen( fname ) , 
                    vname           , 
                    strlen( vname ) , 
                  & jdate           , 
                  & jtime           , 
                    buffer ) ;

    }       /*  end body of write3c ()  */

                	/** END  CASE OF WIN32 write3c() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED write3c(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int WRITE3( const _fcd    fname ,
                       const _fcd    vname ,
                       const  int  * jdate ,
                       const  int  * jtime ,
                       const  void * buffer ) ;

int write3c( const char  * fname ,
             const char  * vname ,
             int           jdate ,
             int           jtime ,
             const void  * buffer )
 
    {       /*  begin body of write3c() */
    
    _fcd  file ;
    _fcd  vble ;
    
    file = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble = _cptofcd( (char *)vname, strlen( vname ) ) ;

    return _btol( WRITE3(  file , 
                           vble , 
                         & jdate, 
                         & jtime,
                           buffer ) ) ; 
                     
    }       /*  end body of write3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED write3c(): **/

#else

#error   "Error compiling write3c():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

