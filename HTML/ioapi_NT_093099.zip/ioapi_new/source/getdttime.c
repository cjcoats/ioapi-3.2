/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/
#include <time.h>
#include <stdlib.h>		/* JEB */
#include  "parms3.h"
#include "iodecl3.h"    /* JEB */


#if FLDMN && !defined(_WIN32)
#define GETDTTIME getdttime_
#elif defined(__hpux) || defined(_AIX)
#define GETDTTIME getdttime
#endif


void GETDTTIME  ( int *now_date, int *now_time )

/**************************************************************************/
/* PURPOSE:  get current date and time from system using  time()          */
/*                                                                        */
/* PRECONDITIONS:  current date before 2038, when  time()  fails          */
/*                 on 32-bit machines.                                    */
/*                                                                        */
/* CALLS:  standard library function  time()                              */
/*                                                                        */
/* REVISION HISTORY:  prototype  5/91 by CJC                              */
/*                                                                        */
/**************************************************************************/

    {                                  /*  begin body of getdttime() */
    int      yrs, days, hrs, mins, secs ;
    time_t   elap ;

    /** time() returns seconds since basetime  00:00:00 Jan. 1, 1970  **/
    /**        or  0  for failure, as a  time_t == unsigned long      **/

    if ( ! ( elap = time ( (time_t *) 0 ) ) )
        {
        exit ( 2 ) ;
        } /**  END IF-BLOCK:  call to  time() failed **/


    secs = (int)( elap % 60 ) ;
    elap /= 60 ;     /** now in  minutes **/

    mins = (int)( elap % 60 ) ;
    elap /= 60 ;     /** now in  hours   **/

    hrs  = (int)( elap % 24 ) ;
    elap /= 24 ;     /** now in  days **/

    *now_time = 100 * ( 100 * hrs  +  mins )  +  secs ;


    for ( yrs = 1970 ; ; ) /** loop unrolled for leap-year cycle **/
        {
        if ( elap < 365 ) /** year == 2 mod 4 (e.g., 1970 itself) **/
            {
            days = elap + 1 ;
            break ;
            }         /**  END IF-BLOCK testing elap  **/
        else
            {
            elap -= 365 ;
            yrs  += 1   ;
            }         /**  END ELSE-BLOCK incrementing year(==2) and day  **/

        if ( elap < 365 ) /** year == 3 mod 4 **/
            {
            days = elap + 1 ;
            break ;
            }         /**  END IF-BLOCK testing elap  **/
        else
            {
            elap -= 365 ;
            yrs  += 1   ;
            }         /**  END ELSE-BLOCK incrementing year(==3) and day  **/

        days = ( yrs%100 ? 366 : ( yrs%400 ? 365 : 366 ) ) ;
        if ( elap < days )
            {                     /** year == 0 mod 4:  process ?leap years  **/
            days = elap + 1 ;     /** NOTE:  noncentury years are leap years **/
            break ;               /** century years iff divisible by 400     **/
            }         /**  END IF-BLOCK testing elap  **/
        else
            {
            elap -= days ;
            yrs  += 1   ;
            }         /**  END ELSE-BLOCK incrementing year(==0) and day  **/

        if ( elap < 365 ) /** year == 3 mod 4 **/
            {
            days = elap + 1 ;
            break ;
            }         /**  END IF-BLOCK testing elap  **/
        else
            {
            elap -= 365 ;
            yrs  += 1   ;
            }         /**  END ELSE-BLOCK incrementing year(==3) and day  **/

        }         /**  END FOR-LOOP calculating yrs and days **/


    *now_date = 1000 * yrs  +  days ;

    return ;

    }                                  /*  end body of getdttime()  */

