/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	Return day (1-7) of the week for the given Julian date

PRECONDITIONS
	time coded HHMMSS  100 * ( 100 * hours + minutes ) + seconds

CALLS
	none

REVISION HISTORY
	prototype  3/95 byu CJC
                    
**************************************************************************/

#include  "iodecl3.h"


int wkdayc ( int jdate )
    {
    int  year, jday, k ;
    year  = jdate ;
    jday  = jdate % 1000 ;
    k     = year - 1 ;
    k     = k * 365  +  k / 4  -  k / 100  +  k / 400  +  jday  -  1 ;
    return  1  +  k % 7 ;

    }       /*  end body of wkdayc()  */

