/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Generate simple error messages for Models-3 core;
C	terminate program execution iff FATAL.
C
C PRECONDITIONS:
C	JDATE:JTIME represented as YYYYDDD:HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 4/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)

#define M3ERR m3err_

#elif defined(__hpux) || defined(_AIX)

#define M3ERR m3err

#endif


#if defined(M3ERR)

    extern void M3ERR( const char * caller ,
                       const int  * jdate ,
                       const int  * jtime ,
                       const char * errtxt ,
                       const int  * fatal ,
                       int          clen ,
                       int          elen ) ;

void m3errc( const char          * caller ,
             int                   jdate ,
             int                   jtime ,
             const char          * errtxt ,
             int                   fatal )

    {       /*  begin body of m3errc() */

    M3ERR( caller, &jdate, &jtime, errtxt, &fatal,
           strlen( caller ) , strlen( errtxt ) ) ;
    return ;

    }       /*  end body of m3errc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED m3errc(): **/

#elif  defined(_WIN32)


    extern void M3ERR( const char * caller ,
                       int          clen ,
                       const int  * jdate ,
                       const int  * jtime ,
                       const char * errtxt ,
                       int          elen,  /* JEB moved */
                       const int  * fatal ) ;

void m3errc( const char          * caller ,
             int                   jdate ,
             int                   jtime ,
             const char          * errtxt ,
             int                   fatal )

    {       /*  begin body of m3errc() */

    M3ERR( caller, strlen( caller ), &jdate, &jtime, 
           errtxt, strlen( errtxt ), &fatal ) ;
    return ;

    }       /*  end body of m3errc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED m3errc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern void M3ERR( const _fcd   caller , 
                       const  int * jdate  ,
                       const  int * jtime  ,
                       const _fcd   errtxt ,
                       const  int * fatal  ) ;

void m3errc( const char          * caller ,
             int                   jdate  ,
             int                   jtime  ,
             const char          * errtxt , 
             int                   fatal )

    {       /*  begin body of m3errc() */
    
    _fcd  cname ;
    _fcd  etext ;
     int  flag  ;
    
    cname = _cptofcd( (char *)caller, strlen( caller ) ) ;
    etext = _cptofcd( (char *)errtxt, strlen( errtxt ) ) ;
    flag  = _ltob( fatal ) ;

    M3ERR( cname, &jdate, &jtime, etext, &flag ) ;
    return ;
                     
    }       /*  end body of m3errc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED m3errc(): **/

#else

#error   "Error compiling m3errc():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

