/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C       Opens Models-3 file with the specified logical name and
C       file description.  Wrapper around I/O API Fortran-binding
C       routine GETDFILE()
C
C PRECONDITIONS:
C
C CALLS:
C       Fortran I/O API utility routine GETDFILE()
C
C REVISION HISTORY:
C       Prototype 3/95 by CJC
C       Version   9/99 by CJC adds WIN32 support
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


                /** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */
#define GETDFILE getdfile_
#elif defined(__hpux) || defined(_AIX)
#define GETDFILE getdfile
#endif


#if defined(GETDFILE)

                /** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int GETDFILE( const char * fname ,
                         const int  * rwstatus ,
                         const int  * fmstatus ,
                         const int  * reclen   ,
                         const char * pname    ,
                         int          fnamelen ,
                         int          pnamelen ) ;

int getdfilec( const char * fname  ,
               int          rstatus,
               int          fstatus,
               int          reclen ,
               const char * pname )

    {       /*  begin body of getdfilec() */
    char nbuf[  32 ] ;
    char mbuf[ 256 ] ;
    int  rwstatus ;
    int  fmstatus ;
    
    rwstatus = ( rstatus != 0 ) ;
    fmstatus = ( fstatus != 0 ) ;

    return GETDFILE(  fname    ,
                    & rwstatus ,
                    & fmstatus ,
                    & reclen   ,
                      pname    ,
                      (int) strlen( fname ) ,
                      (int) strlen( pname ) ) ;

    }       /*  end body of getdfilec ()  */

                        /** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                        /** NEXT CASE:  WIN32-TARGETED getdfilec(): **/

#elif  defined(_WIN32)

extern int GETDFILE( const char * fname ,
                     int          fnamelen ,
                     const int  * rwstatus ,
                     const int  * fmstatus ,
                     const int  * reclen   ,
                     const char * pname    ,
                     int          pnamelen ) ;

int getdfilec( const char * fname  ,
               int          rstatus,
               int          fstatus,
               int          reclen ,
               const char * pname )

    {       /*  begin body of getdfilec() */
    int  rwstatus ;
    int  fmstatus ;
    
    rwstatus = ( rstatus != 0 ) ;
    fmstatus = ( fstatus != 0 ) ;

    return GETDFILE(  fname    ,
                      (int) strlen( fname ) ,
                    & rwstatus ,
                    & fmstatus ,
                    & reclen   ,
                      pname    ,
                      (int) strlen( pname ) ) ;

    }       /*  end body of WIN32 getdfilec ()  */


                        /** END  CASE OF WIN32 F77 TARGETS **/
                        /** NEXT CASE:  CRAY CF77-TARGETED getdfilec(): **/


#elif  defined(_CRAY)


#include <fortran.h>

    extern int GETDFILE( const _fcd   fname ,
                         const  int * rwstatus,
                         const  int * fmstatus,
                         const  int * reclen,
                         const _fcd   pname ) ;

int getdfilec( const char          * fname ,
               int                   rstatus,
               int                   fstatus,
               int                   reclen,
               const char          * pname )

    {       /*  begin body of getdfilec() */
    
    _fcd  file ;
    _fcd  prgm ;

    int   rstat ;
    int   fstat ;

    char  nbuf[  32 ] ;
    char  mbuf[ 256 ] ;

    file = _cptofcd( (char *)fname, (int) strlen( fname ) ) ;
    prgm = _cptofcd( (char *)pname, (int) strlen( pname ) ) ;

    rstat = _ltob( rstatus ) ;
    fstat = _ltob( fstatus ) ;

    return GETDFILE( file, 
                     &rstat, 
                     &fstat, 
                     &reclen,
                     prgm ) ;
                     
    }       /*  end body of getdfilec ()  */

                        /** END  CASE OF CRAY CF77-TARGETED getdfilec(): **/

#else

#error   "Error compiling getdfilec():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

