/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	format and return the date as a character string "M+ D+, YYYY"
C
C PRECONDITIONS:
C	valid Julian date YYYYDDD, time HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Revised   8/99 by CJC -- bug fix for leap-years
C
**************************************************************************/

#include  <string.h>
#include  <stdio.h>
#include  "iodecl3.h"

void   mmddyyc( int   jdate ,
                char  buffer[ 15 ] )
{
static const char   months[ 12 ][ 6 ] =
    { 
    "Jan." , "Feb." , "March", "April", "May"  , "June",
    "July" , "Aug." , "Sept.", "Oct." , "Nov." , "Dec." } ;
    
static const int    cumday[ 13 ] = 
    {
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365
    } ;		/** Lookup table of cumulative days accumulated  **/
    		/** (in non-leap year) before the given month. **/
		/** CUMDAY(13) is total days per year. **/
    
static const int    leapday[ 13 ] = 
    {
    0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366
    } ;		/** Lookup table of cumulative days accumulated  **/
    		/** (in leap year) before the given month. **/
		/** LEAPDAY(13) is total days per year. **/
    
int   year, iday, mnth, leap ;

if ( jdate > 9999999 || jdate < 0 ) 
    {                                
    fprintf( stderr, 
             "\n\n*** %s ***\n    %s %d\n",
             "Year-number error in mmddyyc()",
             "jdate = ", jdate ) ;
    strcpy( buffer, "<DATE ERROR>" ) ;
    return ;
    }

year = jdate / 1000 ;
iday = jdate % 1000 ;

leap = ( year % 4 == 0 ) && ( year % 100 ? 1 : ( year % 400 == 0 ) ) ;

if ( leap )
    {
    for( mnth = 0 ; mnth < 13 ; mnth++ )
        {
        if ( iday <= leapday[ mnth+1 ] )
            {
            sprintf( buffer, 
                     "%s %d, %4d\0",
                     months[ mnth ],
                     iday - leapday[ mnth],
                     year ) ;
            return ;
            } ;
        }
    }
else
    {
    for( mnth = 0 ; mnth < 13 ; mnth++ )
        {
        if ( iday <= cumday[ mnth+1 ] )
            {
            sprintf( buffer, 
                     "%s %d, %4d\0",
                     months[ mnth ],
                     iday - cumday[ mnth],
                     year ) ;
            return ;
            } ;
        }
    } ;

/** If you get to here:  bad arguments **/

fprintf( stderr, 
         "\n\n*** %s ***\n    %s %d\n",
         "Bad argument to mmddyyc()",
         "jdate = ", jdate ) ;
         
strcpy( buffer, "<DATE ERROR>" ) ;
return ;
    
}		/** END BODY OF void mmddyyc() **/

