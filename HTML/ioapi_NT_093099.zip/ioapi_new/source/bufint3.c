/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************/
/* public  function BUFVGT3()  starts at line 108                         */
/* public  function BUFINT3()  starts at line 151                         */
/* public  function BUFCRE3()  starts at line 230                         */
/* public  function BUFPUT3()  starts at line 266                         */
/* public  function BUFGET3()  starts at line 315                         */
/* public  function BUFXTR3()  starts at line 350                         */
/* public  function BUFDDT3()  starts at line 410                         */
/* public  function BUFDEL3()  starts at line 455                         */
/*                                                                        */
/* NOTE:  MACHINE-DEPENDENT CODE !!!  Dependent upon the                  */
/*        representation of Fortran LOGICAL  variables                    */
/*        .TRUE. as binary all-ones, and .FALSE. as zero.                 */
/*                                                                        */
/* PURPOSE:                                                               */
/*       Supports INTERP3.FOR and buffering for "virtual files" to be     */
/*       used as structured communications channels.                      */
/*       Should be considered the buffer management part of INTERP3.FOR.  */
/*       Interpolates specified variable from file with specified         */
/*       ID, according to time step and interpolation coefficients        */
/*       p, q, putting the result in the specified buffer.                */
/*       Allocates and manages circular buffers used in the interpolation,*/
/*       and performs reads (using NCVGT()) whenever specified by         */
/*       rflag.                                                           */
/*                                                                        */
/*  RETURN VALUE:                                                         */
/*       TRUE iff the operation succeeds (and the data is available)      */
/*                                                                        */
/* PRECONDITIONS:                                                         */
/*       Correct set-up by INTERP3.F.                                     */
/*                                                                        */
/* CALLS: see above                                                       */
/*                                                                        */
/* CALLED BY: INTERP3()                                                   */
/*                                                                        */
/* REVISION HISTORY:                                                      */
/*       Prototype 4/93 by CJC                                            */
/*       Modified  8/94 by CJC:  BUFFERED "virtual files" with CREATE3(), */
/*                               READ3(), WRITE3(), INTERP3(), XTRACT3()  */
/*       Modified 10/94 by CJC:  write for individual variables           */
/*       Modified  8/95 by CJC:  support for CLOSE3()                     */
/**************************************************************************/

#include <stdio.h>
#ifdef _WIN32
#include <stdlib.h>		/* JEB */
#include <malloc.h>		/* JEB */
#endif
#include "parms3.h"
#include "iodecl3.h"


/**  DEAL WITH  FELDMANISMS  OF MANY UN*X F77'S   **/

#ifndef _WIN32     /* JEB */
#if FLDMN

#define  RDVARS    rdvars_
#define  BUFVGT3   bufvgt3_
#define  BUFCRE3   bufcre3_
#define  BUFDEL3   bufdel3_
#define  BUFDDT3   bufddt3_
#define  BUFGET3   bufget3_
#define  BUFINT3   bufint3_
#define  BUFPUT3   bufput3_
#define  BUFXTR3   bufxtr3_

#elif defined(__hpux) || defined(_AIX)

#define  RDVARS    rdvars
#define  BUFVGT3   bufvgt3
#define  BUFCRE3   bufcre3
#define  BUFDEL3   bufdel3
#define  BUFDDT3   bufddt3
#define  BUFGET3   bufget3
#define  BUFINT3   bufint3
#define  BUFPUT3   bufput3
#define  BUFXTR3   bufxtr3

#endif
#endif				/* JEB */


/** EXTERNAL FORTRAN FUNCTION FOR READING NETCDF DATA: **/

        extern int RDVARS( int *fid,     int *vid,
                           int dims[],   int delts[], int *delta,
                           void *buffer ) ;


/*****************  STATE VARIABLES ************************************/

    /** BUFFER ADDRS, OR 0:  NOTE THAT FORTRAN (1-BASED) SUBSCRIPTING USED **/

    static FREAL *baddr[ MXFILE3+1 ][ MXVARS3+1 ] ;


/*****************  BUFINT3: *****************************************/
/** Do time interpolation for INTERP3() **/
    
int BUFVGT3 ( int   *fndx,      /** M3 file index **/
              int   *vndx,      /** M3 variable index **/
              int   *rflag,     /** read-only flag **/
              int    dims[],    /** hyperslab corner arg for NCVGT() **/
              int    delt[],    /** hyperslab diagonal arg for NCVGT() **/
              int   *bsize,     /** buffer size **/
              int   *delta,     /** offset for read-op **/
              int   *tstep )    /** TRUE iff time-dependent file **/

    {  /**  begin body of bufint3() **/

/* JEB    int    i , j ;   */           /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size ;               /** SCRATCH VARIABLE:  BUFFER SIZE  **/
    int    ierr ;               /** RETURN FLAG FOR NCVGT()  **/
    FREAL *bptr /* JEB, *pptr, *qptr */; /** FOR TRAVERSING INTERPOLATION BUFFER **/
/* JEB    FREAL  pp , qq ;      */      /** COEFFS AT P,Q **/
    char   mesg[ 81 ] ;

    if ( ! ( bptr = baddr[ *fndx ][ *vndx ] ) )   /** NOT YET ALLOCATED **/
        {
        size = ( *tstep ? 2 : 1 ) * sizeof( FREAL ) * (*bsize );

        bptr = baddr[ *fndx ][ *vndx ] = (FREAL *) malloc( size ) ;

        if ( ! bptr )    /** CHECK FOR MALLOC() FAILURE **/
            {
            m3mesgc( "Error allocating internal buffer for INTERP3()" ) ;
            return( 0 ) ;
            }                   /**  END IF-BLOCK:  MALLOC() FAILED **/

        }           /**  END IF-BLOCK:  NEED TO ALLOCATE THIS VARIABLE **/

    if ( *rflag )                               /** READ IS NECESSARY **/
        {
        size = ( *bsize ) * ( *delta ) ;        /**  = OFFSET FOR READ **/
        ierr = RDVARS( fndx, vndx, dims, delt, &size, bptr + size ) ;
        if ( ! ierr )  
            {
            sprintf( mesg, "netCDF error %d reading file", ierr ) ;
            m3mesgc( mesg ) ;
            return( 0 ) ;
            }
        }                       /**  END IF-BLOCK:  READ NECESSARY **/

    return( -1 ) ;              /** .TRUE. **/

    }           /**  END FUNCTION bufvgt3() **/



/*****************  BUFINT3: *****************************************/
/** Do time interpolation for INTERP3() **/
    
int BUFINT3 ( int   *fndx,      /** M3 file index **/
              int   *vndx,      /** M3 variable index **/
              int   *bsize,     /** buffer size **/
              int   *last,      /**   " for p coeff in interpolation **/
              int   *tstep,     /** TRUE iff time-dependent file **/
              FREAL *p,         /** interpolation coeff for last **/
              FREAL *q,         /** ... for (1 - last) **/
              FREAL *buffer )   /** output buffer array **/

    {  /**  begin body of bufint3() **/

    int    i /* JEB, j */ ;              /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size ;               /** SCRATCH VARIABLE:  BUFFER SIZE  **/
/* JEB    int    ierr ;   */            /** RETURN FLAG FOR NCVGT()  **/
    FREAL *bptr, *pptr, *qptr ; /** FOR TRAVERSING INTERPOLATION BUFFER **/
    FREAL  pp , qq ;            /** COEFFS AT P,Q **/
/* JEB    char   mesg[ 81 ] ;   */

    if ( ! ( bptr = baddr[ *fndx ][ *vndx ] ) )   /** NOT YET ALLOCATED **/
        {
        m3mesgc( "Error referencing internal buffer for INTERP3()" ) ;
        return( 0 ) ;
        }           /**  END IF-BLOCK:  NEED TO ALLOCATE THIS VARIABLE **/

    size = *bsize ;             /** = SIZEOF( TIME-STEP RECORD ) **/

    if ( *tstep )        /** IF TIME-STEPPED FILE **/
        {
        pp   = *p ;      /** BY CONSTRUCTION:  pp + qq = 1; pp,qq >= 0 **/
        qq   = *q ;
        if ( qq == 0.0 ) 
            {
            for  ( i = 0 , pptr = bptr + ( *last ? size : 0 ) ;
                   i < size ;
                   i++ )
                {
                buffer[ i ] = pptr[ i ] ;
                }                   /**  END FOR-LOOP ON I:  COPY BUFFER **/
            }                       /** IF TIME-STEPPED FILE OR NOT **/
        else if ( pp == 0.0 ) 
            {
            for  ( i = 0 , qptr = bptr + ( *last ? 0 : size ) ;
                   i < size ;
                   i++ )
                {
                buffer[ i ] = qptr[ i ] ;
                }                   /**  END FOR-LOOP ON I:  COPY BUFFER **/
            }                       /** IF TIME-STEPPED FILE OR NOT **/
        else{
            for  ( i    = 0 ,
                   pptr = bptr + ( *last ? size : 0 ) ,
                   qptr = bptr + ( *last ? 0 : size ) ;
                   i < size ;
                   i++ )
                {
                buffer[ i ] = pp * pptr[ i ]  +  qq * qptr[ i ] ;
                }           /**  END FOR-LOOP ON I:  INTERPOLATE FROM BUFFER **/
            }
        }			/** END IF:  qq==0, or pp==0, OR NOT **/
    else                                /** ELSE TIME-INDEPENDENT FILE **/
        {
        for  ( i = 0 , pptr = bptr ;
               i < size ;
               i++ )
            {
            buffer[ i ] = pptr[ i ] ;
            }                   /**  END FOR-LOOP ON I:  COPY BUFFER **/
        }                       /** IF TIME-STEPPED FILE OR NOT **/

    return( -1 ) ;              /** .TRUE. **/

    }           /**  END FUNCTION bufint3() **/



/*****************  BUFCRE3: *****************************************/
/** CREATE / SET UP INTERNAL BUFFERS FOR WRITE3 **/    

int BUFCRE3 ( int   *fndx,     /** M3 file index **/
              int   *nvars,    /** number of variables **/
              int   *nlays,    /** number of layers **/
              int   *bsize,    /** individual-variable/layer buffer size **/
              int   *tstep )   /** time step or 0 (time-independent data) **/

    {  /**  begin body of bufcre3() **/

    int    i /* JEB, j */ ;                     /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size  ;                     /** RECORD-SIZE **/
/* JEB   FREAL *bptr, *pptr, *qptr, *rptr ; */ /** FOR TRAVERSING BUFFERS **/

    size = sizeof( FREAL ) * ( *bsize ) * ( *nlays ) * ( *tstep ? 2 : 1 ) ;
    
    if ( ! baddr[ *fndx ][ 1 ] )   /** "FILE" NOT YET ALLOCATED **/
        {
                                   /** SET UP EACH VARIABLE'S ADDRESS **/
        for ( i=1 ;  i <= (*nvars) ;  i++ )
            {
            if ( ! ( baddr[ *fndx ][ i ] = (FREAL *) malloc( size ) ) )
                {
                m3mesgc( "Error allocating internal buffer for OPEN3()" ) ;
                return( 0 ) ;
                }                     /**  END IF-BLOCK:  MALLOC() FAILED **/
            }           /** END LOOP SETTING baddr[][] FOR THIS VARIABLE**/
        }               /**  END IF-BLOCK:  NEED TO ALLOCATE THIS "FILE" **/

    return( -1 ) ;          /** .TRUE. **/

    }           /**  END FUNCTION BUFCRE3() **/



/*****************  BUFPUT3: *****************************************/
/** WRITE TO INTERNAL BUFFERS FOR WRITE3 **/    

int BUFPUT3 ( int   *fndx,     /** M3 file index **/
              int   *vndx,     /** variable index **/
              int   *bsize,    /** individual-variable buffer size **/
              int   *where,    /** 0,1 subscript into circ buffer for WRITE **/
              FREAL *buffer )  /** output buffer array **/

    {  /**  begin body of bufput3() **/

    int  /* JEB  i ,*/ j ;                     /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size ;                      /** TIMESTEP-RECORD SIZE **/
    FREAL *bptr, *pptr, *qptr/* JEB, *rptr */ ; /** FOR TRAVERSING BUFFERS **/
/* JEB    char   mesg[ 81 ] ; */

    size = ( *bsize ) ;
    
    if ( !( bptr = baddr[ *fndx ][ *vndx ] ) ) /** "FILE" NOT YET ALLOCATED **/
        {
        m3mesgc( "BUFFERED file not yet allocated" ) ;
        return( 0 ) ;
        }

    if ( *where ) bptr += size ;
    for  ( j = 0 , pptr = bptr , qptr = buffer ;
           j < size ;
           j++ , pptr++ , qptr++ )
        {
        *pptr = *qptr ;
        }               /**  END FOR-LOOP COPYING THIS VARIABLE **/

    return( -1 ) ;          /** .TRUE. **/

    }           /**  END FUNCTION BUFPUT3() **/



/*****************  BUFGET3: *****************************************/
/** READ TO INTERNAL BUFFERS FOR READ3() **/

int BUFGET3 ( int   *fndx,     /** M3 file     index **/
              int   *vndx,     /** M3 variable index **/
              int   *lndx,     /** M3 layer    index **/
              int   *nlays,    /** number of layers  **/
              int   *bsize,    /** individual-variable buffer size **/
              int   *where,    /** 0,1 subscript into circ buffer for WRITE **/
              FREAL *buffer )  /** output buffer array **/

    {  /**  begin body of bufget3() **/

/* JEB    int    i , j ;  */                   /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size , vsiz /* JEB, tdex */ ;        /** SCRATCH VARIABLES:  BUFFER SIZE  **/
    FREAL *bptr, *pptr, *qptr/* JEB, *rptr */ ; /** FOR TRAVERSING BUFFERS **/

    if ( !( bptr = baddr[ *fndx ][ *vndx ] ) ) 
        {
        m3mesgc( "BUFFERED file not yet allocated" ) ;
        return( 0 ) ;
        }
    
    size = ( *bsize ) ;			/** SIZE OF ONE LAYER  **/
    vsiz = size * ( *nlays ) ;		/** SIZE OF ENTIRE VBLE **/
    if ( *lndx > 0 )
        {
        bptr += ( size * ( *lndx - 1 ) ) ;  /** OFFSET FOR REQUESTED LAYER **/
        }
    else{
        size = vsiz ;			    /** READ ENTIRE VBLE **/
        }
    if ( *where ) bptr += vsiz ;
    
    for  ( pptr = bptr , qptr = buffer ;
           pptr < bptr + size ;
           pptr++, qptr++ )
        {
        *qptr = *pptr ;
        }                   /**  END FOR-LOOP COPYING THIS VARIABLE **/
    
    return( -1 ) ;              /** .TRUE. **/

    }           /**  END FUNCTION BUFGET3() **/


/*****************  BUFXTR3: *****************************************/
/** READ TO INTERNAL BUFFERS FOR XTRACT3() **/

int BUFXTR3 ( int   *fndx,     /** M3 file      index **/
              int   *vndx,     /** M3 variable  index **/
              int   *lolay,    /** lower layer  index for XTRACT window **/
              int   *hilay,    /** upper layer  index **/
              int   *lorow,    /** lower row    index **/
              int   *hirow,    /** upper row    index **/
              int   *locol,    /** lower column index **/
              int   *hicol,    /** upper column index **/
              int   *nlays,    /** number of layers   **/
              int   *nrows,    /** number of rows     **/
              int   *ncols,    /** number of columns  **/
              int   *where,    /** 0,1 subscript into circ buffer for XTRACT **/
              FREAL *buffer )  /** output buffer array **/

    {  /**  begin body of bufget3() **/

#define VALXTR3( L,R,C )  ( *( bptr + nc*( nr*(L) + (R) ) + (C) ) )
    
    int    c , r , l ;                /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    nc, nr, nl ;
    int    loc, hic, lor, hir, lol, hil ;
    FREAL *bptr, *qptr ;

    if ( !( bptr = baddr[ *fndx ][ *vndx ] ) ) 
        {
        m3mesgc( "BUFFERED file not yet allocated." ) ;
        return( 0 ) ;
        }
    
    nc = *ncols ;
    nr = *nrows ;
    nl = *nlays ;
    
    if ( *where ) bptr += ( nc * nr * nl ) ;
    
    loc = *locol - 1 ;  /** compensate for Fortran conventions      **/
    hic = *hicol ;      /** (1-based subscripting) on window bounds **/
    lor = *lorow - 1 ;  /** from calling routine XTRACT3()          **/
    hir = *hirow ;
    lol = *lolay - 1 ;
    hil = *hilay ;
    
    qptr = buffer ;
    
    for  ( l = lol ; l < hil ; l++ )
    for  ( r = lor ; r < hir ; r++ )
    for  ( c = loc ; c < hic ; c++, qptr++ )
        {
        *qptr = VALXTR3( l,r,c ) ;
        }                   /**  END FOR-LOOP-NEST COPYING THIS VARIABLE **/
    

    return( -1 ) ;              /** .TRUE. **/

    }           /**  END FUNCTION BUFXTR3() **/


/*****************  BUFDDT3: *****************************************/
/** Do derivative calculation for DDTVAR3() **/
    
int BUFDDT3 ( int   *fndx,      /** M3 file index **/
              int   *vndx,      /** M3 variable index **/
              int   *bsize,     /** buffer size **/
              int   *last,      /**   " for p coeff in interpolation **/
              int   *tstep,     /** TRUE iff time-dependent file **/
              FREAL *p,         /** 1.0 / timestep **/
              FREAL *buffer )   /** output buffer array **/

    {  /**  begin body of bufint3() **/

    int    i /* JEB , j */ ;              /** LOOP COUNTERS AND SUBSCRIPTS **/
    int    size ;               /** SCRATCH VARIABLE:  BUFFER SIZE  **/
/* JEB    int    ierr ;  */             /** RETURN FLAG FOR NCVGT()  **/
    FREAL *bptr, *pptr, *qptr ; /** FOR TRAVERSING INTERPOLATION BUFFER **/
    FREAL  pp ;                 /** INVERSE TIMESTEP **/
/* JEB    char   mesg[ 81 ] ; */

    if ( ! ( bptr = baddr[ *fndx ][ *vndx ] ) )   /** NOT YET ALLOCATED **/
        {
        m3mesgc( "Error referencing internal buffer for DDTVAR3()" ) ;
        return( 0 ) ;
        }           /**  END IF-BLOCK:  NEED TO ALLOCATE THIS VARIABLE **/

    size = *bsize ;             /** = SIZEOF( TIME-STEP RECORD ) **/

    for  ( i    = 0 ,
           pptr = bptr + ( *last ? size : 0 ) ,
           qptr = bptr + ( *last ? 0 : size ) ,
           pp   = *p ;
           i < size ;
           i++ )
        {
        buffer[ i ] = pp * ( pptr[ i ]  -  qptr[ i ] ) ;
        }           /**  END FOR-LOOP ON I:  INTERPOLATE FROM BUFFER **/

    return( -1 ) ;              /** .TRUE. **/

    }           /**  END FUNCTION BUFDDT3() **/



/*****************  BUFDEL3: *****************************************/
/** free up memory for SHUT3() and CLOSE3()  **/
    
void BUFDEL3 ( int *fndx )     /** M3 file index **/

    {  /** begin body of bufinit() **/
    int    i , j ;              /** LOOP COUNTERS AND SUBSCRIPTS **/

    i = *fndx ;
    for ( j = 0 ; j <= MXVARS3 ; j++ )
        {
        if ( baddr[ i ][ j ] )
            {
            free( (void*) baddr[ i ][ j ] ) ;
            baddr[ i ][ j ] = (FREAL *)0 ;
            }
        }                       /** END LOOP ON J **/

    }  /** end body of bufinit() **/


