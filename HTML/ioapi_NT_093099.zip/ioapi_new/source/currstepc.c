/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	If possible, compute the date&time cdate:ctime for the time 
        step in the time step sequence starting at sdate:stime and 
        having the time step tstep and return TRUE; 
        otherwise, return FALSE.  
        
        In particular, cdate:ctime is the date&time of largest time step
        in the sequence having the property:
        
            cdate:ctime <= jdate:jtime
        
        Return TRUE with cdate=sdate, ctime=stime if tstep==0.

PRECONDITIONS
	normalized dates and times (0 <= SS <= 59, etc.)
	stored in format YYYYDDD:HHMMSS.

CALLS
	none

REVISION HISTORY
	prototype  3/95 by CJC
	revised    9/99 by CJC for I/O API v2:  add WIN32

**************************************************************************/

#include  "iodecl3.h"
#include  <stdlib.h>

#if FLDMN && ! defined(_WIN32)   /* JEB */

#define   CURRSTEP currstep_ 

   extern int  CURRSTEP( int, int, int, int );

#elif defined(__hpux) || defined(_AIX)

#define CURRSTEP              currstep

   extern int  CURRSTEP( int, int, int, int );

#elif defined( _WIN32)

   extern int /* JEB __stdcall */ CURRSTEP( int, int, int, int, int, int, int ); /* JEB, added 3 ints */

#elif  defined(_CRAY)

   extern int  CURRSTEP( int, int, int, int );

#else
 
#error   "Error compiling:  unsupported architecture"
 
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/


int currstepc( int  jdate , int  jtime , 
               int  sdate , int  stime , int  tstep ,
               int *cdate , int *ctime )
    {
    int secs, step ;
    
    if ( tstep ) 
        {
#if defined(_WIN32)        /* JEB */
		secs = CURRSTEP(jdate, jtime, sdate, stime, tstep,
			*cdate, *ctime);	/* JEB */
#else
        secs = CURRSTEP( sdate, stime, jdate, jtime ) ;
#endif
        if ( secs < 0 ) 
            {
            return  0 ;
            }
        else{
            *cdate = sdate ;
            *ctime = stime ;
            step  = time2secc( abs( tstep ) ) ;
            secs  = ( secs / step ) * step ;    /** use truncated step-# **/
            nextimec( cdate, ctime, sec2timec( secs ) ) ;
            return 1 ;
            }
        }
    else{		/** tstep == 0 case **/
        *cdate = sdate ;
        *ctime = stime ;
        return 1 ;
        }                                  

    }       /*  end body of currstepc()  */

