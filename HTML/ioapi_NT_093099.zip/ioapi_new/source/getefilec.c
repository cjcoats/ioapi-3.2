/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Opens Models-3 file with the specified logical name and
C	file description.  Wrapper around I/O API Fortran-binding
C	routine GETEFILE()
C
C PRECONDITIONS:
C	FNAME already opened by GETEFILE() or getefilec()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's GETEFILE()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)
#define GETEFILE getefile_
#elif defined(__hpux) || defined(_AIX)
#define GETEFILE getefile
#endif


#if defined(GETEFILE)

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int GETEFILE( const char * fname ,
                       const int  * rwstatus,
                       const int  * fmstatus,
                       const char * pname,
                       int          fnamelen ,
                       int          pnamelen ) ;

int getefilec( const char * fname ,
               int          rstatus,
               int          fstatus,
               const char * pname )

    {       /*  begin body of getefilec() */
    char nbuf[  32 ] ;
    char mbuf[ 256 ] ;
    int  rwstatus ;
    int  fmstatus ;
    
    rwstatus = ( rstatus != 0 ) ;
    fmstatus = ( fstatus != 0 ) ;

    return GETEFILE(  fname  ,
                    & rwstatus ,
                    & fmstatus ,
                      pname  ,
                      (int) strlen( fname ) ,
                      (int) strlen( pname ) ) ;

    }       /*  end body of getefilec ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32-TARGETED getefilec(): **/

#elif defined(_WIN32)

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int GETEFILE( const char * fname ,
                         int          fnamelen ,
                         const int  * rwstatus,
                         const int  * fmstatus,
                         const char * pname,
                         int          pnamelen ) ;

int getefilec( const char * fname ,
               int          rstatus,
               int          fstatus,
               const char * pname )

    {       /*  begin body of getefilec() */
/* JEB    char nbuf[  32 ] ; */
/* JEB    char mbuf[ 256 ] ; */
    int  rwstatus ;
    int  fmstatus ;
    
    rwstatus = ( rstatus != 0 ) ;
    fmstatus = ( fstatus != 0 ) ;

    return GETEFILE(  fname  ,
                      (int) strlen( fname ) ,
                    & rwstatus ,
                    & fmstatus ,
                      pname  ,
                      (int) strlen( pname ) ) ;

    }       /*  end body of getefilec ()  */

                	/** END  CASE OF WIN32 F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED getefilec(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int GETEFILE( const _fcd   fname ,
                         const  int * rwstatus,
                         const  int * fmstatus,
                         const _fcd   pname ) ;

int getefilec( const char          * fname ,
               int                   rstatus,
               int                   fstatus,
               const char          * pname )

    {       /*  begin body of getefilec() */
    
    _fcd  file ;
    _fcd  prgm ;
    
    int   rstat ;
    int   fstat ;

    char  nbuf[  32 ] ;
    char  mbuf[ 256 ] ;

    file = _cptofcd( (char *)fname, (int) strlen( fname ) ) ;
    prgm = _cptofcd( (char *)pname, (int) strlen( pname ) ) ;

    return GETEFILE( file, 
                     &rstat, 
                     &fstat, 
                     prgm ) ;
                     
    }       /*  end body of getefilec ()  */

                	/** END  CASE OF CRAY CF77-TARGETED getefilec(): **/

#else

#error   "Error compiling getefilec():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

