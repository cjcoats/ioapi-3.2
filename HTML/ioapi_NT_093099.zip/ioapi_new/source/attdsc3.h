/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/************************************************************************
C  INCLUDE FILE  attdsc.h
C
C  CONTAINS:  
C       Hydrology time series file attribute typedefs and extern structs for 
C       C bindings to the I/O API
C
C  DEPENDENT UPON:  
C       consistency with FORTRAN include-files PARMS33.EXT, ATTDSC3.EXT
C
C  REVISION HISTORY:  
C       prototype 12/30/96 by CJC
C
**************************************************************************/

#ifndef    ATTDSC3_DEFINED
#define    ATTDSC3_DEFINED

#include   "parms3.h"

/*************************************************************************      
        Typedef for a MODELS 3 attributes list:  same memory layout
        as the FORTRAN COMMONs BATTS3 and CATTS3.
**************************************************************************/

typedef char   M3Name[ NAMLEN3 ] ; /* Models3 Fortran "name" objects  */
typedef char   M3Line[ MXDLEN3 ] ; /* ... "description-line" objects  */
                
typedef struct { 
               int    natts[ MXVARS3 ] ;            /* # of atts per vble */
               float  fatts[ MXVARS3 ][ MXATTS3 ] ; /* attribute values */
               }
               IOAPI_Batts3 ;

typedef struct { 
               M3Name  vname[ MXVARS3 ][ MXATTS3 ] ; /* attribute names */
               }
               IOAPI_Catts3 ;


#endif    /*   ATTDSC3_DEFINED  */

#if FLDMN || __sgi || __sun || __osf__ || __mips__
    
    extern IOAPI_Batts3 _batts3 ;
    extern IOAPI_Catts3 _catts3 ;

#elif __hpux || _AIX

    extern IOAPI_Batts3  batts3 ;
    extern IOAPI_Catts3  catts3 ;

#elif  _CRAY

    extern IOAPI_Batts3  BATTS3 ;
    extern IOAPI_Catts3  CATTS3 ;

#else
 
#error   "Error compiling:  unsupported architecture"
 
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

/****************   END   attdsc3.h   ***********************************/


