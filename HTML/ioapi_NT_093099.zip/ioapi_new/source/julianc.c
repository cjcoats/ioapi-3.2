/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	Return Julian day (1...365,366) corresponding to the date
        <month - dayofmonth - year>
	NOTE:  This is NOT the Julian DATE -- only the day-number.
	To get the Julian date:

      jdate = 1000 * (year % 100)  +  julianc( year , mnth , mday )

PRECONDITIONS

CALLS
	none

REVISION HISTORY
	prototype  3/95 by CJC
                    
**************************************************************************/

#include  "iodecl3.h"


int julianc ( int year, int month, int mday )
    {
    int  k, m, n ;
    
    m = ( month + 9 ) % 12 ;
    n = (m * 153 + 2) / 5 + mday + 58 ;
    k = ( ( year %   4 ) ? 365 :
        ( ( year % 100 ) ? n++, 366 :
        ( ( year % 400 ) ? 365 : n++, 366 ) ) ) ;
    return  1  +  n % k ;

    }       /*  end body of julianc()  */

