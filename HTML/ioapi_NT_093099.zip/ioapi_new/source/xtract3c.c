/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	reads specified 4D window of variable "vname" from file with 
C 	logical name "fname" and puts it into "buffer".
C   	C wrapper around I/O API Fortran binding routine XTRACT3().
C
C RETURNS:  actual number of time steps read.
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's XTRACT3(), NEXTIME().
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32) /* JEB */      /*  see parms3.h  */
#define XTRACT3 xtract3_
#elif defined(__hpux) || defined(_AIX)
#define XTRACT3 xtract3
#endif

#if defined(XTRACT3)

    extern int XTRACT3( const char *fname , const char *vname ,
                        int        *lolay , int        *hilay ,
                        int        *lorow , int        *hirow ,
                        int        *locol , int        *hicol ,
                        int        *jdate , int        *jtime , 
                        void       *buffer,
                        int         fnamelen ,
                        int         vnamelen ) ;

int xtract3c( const char * fname , const char * vname ,
              int          lolay , int          hilay ,
              int          lorow , int          hirow ,
              int          locol , int          hicol ,
              int          jdate , int          jtime , 
              void       * buffer )

    {       /*  begin body of xtract3c() */ 
    
    return XTRACT3(  fname , 
                     vname , 
                   & lolay , & hilay ,
                   & lorow , & hirow ,
                   & locol , & hicol ,
                   & jdate , & jtime , 
                   buffer,
                   strlen( fname ) , 
                   strlen( vname ) ) ;

    }       /*  end body of xtract3c ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  Win32 xtract3c(): **/

#elif defined(_WIN32)

    extern int XTRACT3( const char *fname , int        fnamelen ,
                        const char *vname , int        vnamelen ,
                        int        *lolay , int        *hilay ,
                        int        *lorow , int        *hirow ,
                        int        *locol , int        *hicol ,
                        int        *jdate , int        *jtime , 
                        void       *buffer );

int xtract3c( const char * fname , const char * vname ,
              int          lolay , int          hilay ,
              int          lorow , int          hirow ,
              int          locol , int          hicol ,
              int          jdate , int          jtime , 
              void       * buffer )

    {       /*  begin body of xtract3c() */ 
    
    return XTRACT3(  fname , strlen( fname ) ,
                     vname , strlen( vname ) ,
                   & lolay , & hilay ,
                   & lorow , & hirow ,
                   & locol , & hicol ,
                   & jdate , & jtime , 
                   buffer );

    }       /*  end body of xtract3c ()  */

                	/** END  CASE OF Win32 xtract3c() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED xtract3c(): **/


#elif  defined(_CRAY)


#include <fortran.h>

    extern int XTRACT3( const _fcd  fname , const _fcd  vname ,
                        int        *lolay , int        *hilay ,
                        int        *lorow , int        *hirow ,
                        int        *locol , int        *hicol ,
                        int        *jdate , int        *jtime ,  
                        void       *buffer ) ;

int xtract3c( const char * fname , const char * vname ,
              int          lolay , int          hilay ,
              int          lorow , int          hirow ,
              int          locol , int          hicol ,
              int          jdate , int          jtime , 
              void       * buffer )
 
    {       /*  begin body of xtract3c() */
    
    _fcd  file ;
    _fcd  vble ;
    
    file = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble = _cptofcd( (char *)vname, strlen( vname ) ) ;

    return _btol( XTRACT3(  file ,    vble , 
                          & lolay , & hilay ,
                          & lorow , & hirow ,
                          & locol , & hicol ,
                          & jdate , & jtime ,  buffer ) ) ; 
                     
    }       /*  end body of xtract3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED xtract3c(): **/

#else

#error   "Error compiling xtract3c():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

