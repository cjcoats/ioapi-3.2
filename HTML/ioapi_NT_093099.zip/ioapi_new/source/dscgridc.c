/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	reads specified layer of variable "cname" from file with 
C 	logical name "gname" and puts it into "buffer".
C	C wrapper around I/O API Fortran binding routine DSCGRID().
C	
C
C PRECONDITIONS:
C	gname already opened by OPEN3() or open3c()
C	cname a valid variable in gname, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's DSCGRID()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)

#define DSCGRID dscgrid_
#define DSCOORD dscoord_

#elif defined(__hpux) || defined(_AIX)

#define DSCGRID dscgrid
#define DSCOORD dscoord

#endif


#if defined(DSCGRID)

    extern int DSCGRID( const char * gname ,
                        char       * cname ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent ,
                        double     * xorig ,
                        double     * yorig ,
                        double     * xcell ,
                        double     * ycell ,
                        int        * ncols ,
                        int        * nrows ,
                        int        * nthik ,
                        int          gnamlen ,
                        int          cnamlen ) ;

    extern int DSCOORD( const char * cname ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent ,
                        int          cnamlen ) ;

int dscgridc( const char * gname ,
              char       * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent ,
              double     * xorig ,
              double     * yorig ,
              double     * xcell ,
              double     * ycell ,
              int        * ncols ,
              int        * nrows ,
              int        * nthik )

    {       /*  begin body of dscgridc() */

    return DSCGRID( gname , 
                    cname , 
                    ctype ,
                    p_alp ,
                    p_bet ,
                    p_gam ,
                    xcent ,
                    ycent ,
                    xorig ,
                    yorig ,
                    xcell ,
                    ycell ,
                    ncols ,
                    nrows ,
                    nthik ,
                    strlen( gname ) , 
                    strlen( cname ) ) ;

    }       /*  end body of dscgridc ()  */

int dscoordc( const char * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent )

    {       /*  begin body of dscgridc() */

    return DSCOORD( cname , 
                    ctype ,
                    p_alp ,
                    p_bet ,
                    p_gam ,
                    xcent ,
                    ycent ,
                    strlen( cname ) ) ;

    }       /*  end body of dscgridc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  CRAY CF77-TARGETED dscgridc(): **/


#elif defined(_WIN32)

    extern int DSCGRID( const char * gname ,
                        int          gnamlen ,
                        char       * cname ,
                        int          cnamlen ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent ,
                        double     * xorig ,
                        double     * yorig ,
                        double     * xcell ,
                        double     * ycell ,
                        int        * ncols ,
                        int        * nrows ,
                        int        * nthik );

    extern int DSCOORD( const char * cname ,
                        int          cnamlen ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent );

int dscgridc( const char * gname ,
              char       * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent ,
              double     * xorig ,
              double     * yorig ,
              double     * xcell ,
              double     * ycell ,
              int        * ncols ,
              int        * nrows ,
              int        * nthik )

    {       /*  begin body of dscgridc() */

    return DSCGRID( gname , 
                    strlen( gname ) , 
                    cname , 
                    strlen( cname ) ,
                    ctype ,
                    p_alp ,
                    p_bet ,
                    p_gam ,
                    xcent ,
                    ycent ,
                    xorig ,
                    yorig ,
                    xcell ,
                    ycell ,
                    ncols ,
                    nrows ,
                    nthik );

    }       /*  end body of dscgridc ()  */


#elif  defined(_CRAY)

#include <fortran.h>

    extern int DSCGRID( const _fcd   gname ,
                        _fcd         cname ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent ,
                        double     * xorig ,
                        double     * yorig ,
                        double     * xcell ,
                        double     * ycell ,
                        int        * ncols ,
                        int        * nrows ,
                        int        * nthik ) ;

    extern int DSCOORD( const _fcd   cname ,
                        int        * ctype ,
                        double     * p_alp ,
                        double     * p_bet ,
                        double     * p_gam ,
                        double     * xcent ,
                        double     * ycent ) ;

int dscgridc( const char * gname ,
              char       * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent ,
              double     * xorig ,
              double     * yorig ,
              double     * xcell ,
              double     * ycell ,
              int        * ncols ,
              int        * nrows ,
              int        * nthik )

    {       /*  begin body of dscgridc() */

    _fcd  grid;
    _fcd  coord;
    
    grid  = _cptofcd( (char *)gname, strlen( gname ) ) ;
    coord = _cptofcd( (char *)cname, strlen( cname ) ) ;

    return _btol( DSCGRID( grid  ,
                           coord , 
                           ctype ,
                           p_alp ,
                           p_bet ,
                           p_gam ,
                           xcent ,
                           ycent ,
                           xorig ,
                           yorig ,
                           xcell ,
                           ycell ,
                           ncols ,
                           nrows ,
                           nthik ) ) ;
                     
    }       /*  end body of dscgridc ()  */

int dscoordc( const char * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent )

    {       /*  begin body of dscgridc() */

    _fcd  coord;
    
    coord = _cptofcd( (char *)cname, strlen( cname ) ) ;

    return _btol( DSCOORD( coord, 
                           ctype ,
                           p_alp ,
                           p_bet ,
                           p_gam ,
                           xcent ,
                           ycent  ) ) ;
                     
    }       /*  end body of dscgridc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED dscgridc(): **/

#else

#error   "Error compiling dscgridc():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

