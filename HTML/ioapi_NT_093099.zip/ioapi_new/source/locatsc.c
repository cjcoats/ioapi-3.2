/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
        Return subscript at which integer entry found in SORTED 
        key-tables -- versions for single-key through quadruple-key
        tables, 
        Returns negative number in case of failure.

PRECONDITIONS
        
        Sorted tables list<n>

CALLS
        none

REVISION HISTORY
        prototype  3/95 by CJC
                    
**************************************************************************/

#include  "iodecl3.h"

#if FLDMN && !defined(_WIN32)   /* JEB */

#define  LOCAT1  locat1_
#define  LOCAT2  locat2_
#define  LOCAT3  locat3_
#define  LOCAT4  locat4_

#define  LOCATR1  locatr1_
#define  LOCATR2  locatr2_
#define  LOCATR3  locatr3_
#define  LOCATR4  locatr4_

#elif defined(__hpux) || defined(_AIX)

#define  LOCAT1  locat1
#define  LOCAT2  locat2
#define  LOCAT3  locat3
#define  LOCAT4  locat4

#define  LOCATR1  locatr1
#define  LOCATR2  locatr2
#define  LOCATR3  locatr3
#define  LOCATR4  locatr4

#elif  defined(_CRAY) || defined(_WIN32)

#else
 
#error   "Error compiling locatsc():  unsupported architecture"
 
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/
                                        /** I/O API functions **/


    extern int LOCAT1( int  *k1, 
                       int  *n , 
                       const int *list1 ) ;

    extern int LOCAT2( int  *k1, 
                       int  *k2, 
                       int  *n , 
                       const int *list1 ,
                       const int *list2 ) ;

    extern int LOCAT3( int  *k1, 
                       int  *k2, 
                       int  *k3, 
                       int  *n , 
                       const int *list1 ,
                       const int *list2 ,
                       const int *list3 ) ;

    extern int LOCAT4( int  *k1, 
                       int  *k2, 
                       int  *k3, 
                       int  *k4, 
                       int  *n , 
                       const int *list1 ,
                       const int *list2 ,
                       const int *list3 ,
                       const int *list4 ) ;

    extern int LOCATR1( FREAL *k1, 
                        int   *n , 
                        const FREAL *list1 ) ;

    extern int LOCATR2( FREAL *k1, 
                        FREAL *k2, 
                        int   *n , 
                        const FREAL *list1 ,
                        const FREAL *list2 ) ;

    extern int LOCATR3( FREAL *k1, 
                        FREAL *k2, 
                        FREAL *k3, 
                        int   *n , 
                        const FREAL *list1 ,
                        const FREAL *list2 ,
                        const FREAL *list3 ) ;

    extern int LOCATR4( FREAL *k1, 
                        FREAL *k2, 
                        FREAL *k3, 
                        FREAL *k4, 
                        int   *n , 
                        const FREAL *list1 ,
                        const FREAL *list2 ,
                        const FREAL *list3 ,
                        const FREAL *list4 ) ;


int locat1c( int        k1,      /** first  key component **/
             int        n,       /** table size **/
             const int *list1 )  /** first  key table **/
    {
    int ll ;
    ll = LOCAT1( &k1, &n, list1 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locat1c()  */

int locat2c( int        k1,      /** first  key component **/
             int        k2,      /** second key component **/
             int        n,       /** table size **/
             const int *list1 ,  /** first  key table **/
             const int *list2 )  /** second key table **/
    {
    int ll ;
    ll = LOCAT2( &k1, &k2, &n, list1, list2 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locat2c()  */

int locat3c( int        k1,      /** first  key component **/
             int        k2,      /** second key component **/
             int        k3,      /** third  key component **/
             int        n,       /** table size **/
             const int *list1 ,  /** first  key table **/
             const int *list2 ,  /** second key table **/
             const int *list3 )  /** third  key table **/
    {
    int ll ;
    ll = LOCAT3( &k1, &k2, &k3, &n, list1, list2, list3 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locat3c()  */

int locat4c( int        k1,      /** first  key component **/
             int        k2,      /** second key component **/
             int        k3,      /** third  key component **/
             int        k4,      /** fourth key component **/
             int        n,       /** table size **/
             const int *list1 ,  /** first  key table **/
             const int *list2 ,  /** second key table **/
             const int *list3 ,  /** third  key table **/
             const int *list4 )  /** fourth key table **/
    {
    int ll ;
    ll = LOCAT4( &k1, &k2, &k3, &k4, &n, list1, list2, list3, list4 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locat4c()  */


int locatr1c( FREAL        k1,      /** first  key component **/
              int          n,       /** table size **/
              const FREAL *list1 )  /** first  key table **/
    {
    int ll ;
    ll = LOCATR1( &k1, &n, list1 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locatr1c()  */

int locatr2c( FREAL        k1,      /** first  key component **/
              FREAL        k2,      /** second key component **/
              int          n,       /** table size **/
              const FREAL *list1 ,  /** first  key table **/
              const FREAL *list2 )  /** second key table **/
    {
    int ll ;
    ll = LOCATR2( &k1, &k2, &n, list1, list2 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locatr2c()  */

int locatr3c( FREAL        k1,      /** first  key component **/
              FREAL        k2,      /** second key component **/
              FREAL        k3,      /** third  key component **/
              int          n,       /** table size **/
              const FREAL *list1 ,  /** first  key table **/
              const FREAL *list2 ,  /** second key table **/
              const FREAL *list3 )  /** third  key table **/
    {
    int ll ;
    ll = LOCATR3( &k1, &k2, &k3, &n, list1, list2, list3 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locatr3c()  */

int locatr4c( FREAL        k1,      /** first  key component **/
              FREAL        k2,      /** second key component **/
              FREAL        k3,      /** third  key component **/
              FREAL        k4,      /** fourth key component **/
              int          n,       /** table size **/
              const FREAL *list1 ,  /** first  key table **/
              const FREAL *list2 ,  /** second key table **/
              const FREAL *list3 ,  /** third  key table **/
              const FREAL *list4 )  /** fourth key table **/
    {
    int ll ;
    ll = LOCATR4( &k1, &k2, &k3, &k4, &n, list1, list2, list3, list4 ) ;
    return ( ll > 0 ? -1 + ll : -1 ) ;
    }                           /*  end body of locatr4c()  */


