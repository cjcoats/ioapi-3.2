/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	convert back and forth between Models-3 time conventions and 
	seconds

PRECONDITIONS
	time coded HHMMSS = 100 * ( 100 * hours + minutes ) + seconds

CALLS
	none

REVISION HISTORY
	prototype  3/95 byu CJC

**************************************************************************/

#include  "iodecl3.h"


#if FLDMN && !defined(_WIN32)
#    define    NEXTIME  nextime_
#elif defined(__hpux) || defined(_AIX)
#    define    NEXTIME  nextime
#elif  defined(_CRAY) || defined(_WIN32)
     /** do nothing **/
#else
#    error   "Error compiling init3c():  unsupported architecture"
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/


    extern void  NEXTIME( int   * jdate, 
                          int   * jtime, 
                          int   * tstep ) ;

void nextimec ( int  * jdate,  int  * jtime, int tstep )
    {
    NEXTIME( jdate, jtime,  &tstep ) ;
    }       /*  end body of nextimec()  */
                	/** END  CASE OF CRAY CF77-TARGETED init3c(): **/


