/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
	returns the time interval (seconds) between ADATE:ATIME
	and ZDATE:ZTIME

PRECONDITIONS
	normalized dates and times (0 <= SS <= 59, etc.)
	tored in format YYYYDDD:HHMMSS.

CALLS
	none

REVISION HISTORY
	prototype  3/95 byu CJC

**************************************************************************/

#include  "iodecl3.h"


int secsdiffc( int  adate , 
               int  atime , 
               int  zdate , 
               int  ztime )
    {
    int  days, hours, mins, secs, total ;

/** start with day, hour, min, sec diffe **/
    
    days  =   zdate % 1000         -    adate % 1000 ;
    hours =   ztime / 10000        -    atime / 10000 ;
    mins  = ( ztime / 100 ) % 100  -  ( atime / 100 ) % 100 ;
    secs  =   ztime % 100          -    atime % 100 ;
    total = 60 * ( 60 * ( 24 * days + hours ) + mins ) + secs ;
    
/** Now add corrections for differences in years **/
    
    for ( adate/=1000 ,  zdate/=1000 ; adate < zdate ; adate++ )
        {
        if      ( adate %   4 ) total += 365 * 86400 ;
        else if ( adate % 100 ) total += 366 * 86400 ;
        else if ( adate % 400 ) total += 365 * 86400 ;
        else                    total += 366 * 86400 ;
        }

    for ( ; zdate < adate ; zdate++ )
        {
        if      ( zdate %   4 ) total += 365 * 86400 ;
        else if ( zdate % 100 ) total += 366 * 86400 ;
        else if ( zdate % 400 ) total += 365 * 86400 ;
        else                    total += 366 * 86400 ;
        }
    
    return  total ;

    }       /*  end body of secsdiffc()  */

