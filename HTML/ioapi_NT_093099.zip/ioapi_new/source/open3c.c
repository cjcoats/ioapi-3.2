/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1999 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Opens Models-3 file with the specified logical name and
C	file description.  Wrapper around I/O API Fortran-binding
C	routine OPEN3()
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's OPEN3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Version   8/99 by CJC:  FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)

#define OPEN3 open3_

#elif defined(__hpux) || defined(_AIX)

#define OPEN3 open3

#endif


#if defined(OPEN3)

    extern int OPEN3( const char * fname ,
                      const int  * status,
                      const char * pname,
                      int          fnamelen ,
                      int          pnamelen ) ;

    extern IOAPI_Bdesc3 bdesc3 ;
    extern IOAPI_Cdesc3 cdesc3 ;

int open3c( const char          * fname ,
            const IOAPI_Bdesc3  * bdesc ,
            const IOAPI_Cdesc3  * cdesc ,
            int                   status,
            const char          * pname )

    {       /*  begin body of open3c() */
    char nbuf[  32 ] ;
    char mbuf[ 256 ] ;

    if ( ( status == FSNEW3  ) || 
         ( status == FSUNKN3 ) ||
         ( status == FSCREA3 ) )
        {
        if ( ( ! bdesc ) || ( ! cdesc ) )
            {
            sprintf( nbuf, "%s:%s", pname, "open3c()" ) ;
            sprintf( mbuf, "%s( %s )", 
                           "Null passed to open3c", fname ) ;
            m3errc( nbuf, 0, 0, mbuf, 0 ) ;
            return( 0 ) ;
            }
    
        memcpy( (void*) &bdesc3, (void*) bdesc, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) &cdesc3, (void*) cdesc, sizeof( IOAPI_Cdesc3 ) ) ;
    
        }	/** if opened "new" or "unknown" **/

    return OPEN3(  fname  ,
                 & status ,
                   pname  ,
                   (int) strlen( fname ) ,
                   (int) strlen( pname ) ) ;

    }       /*  end body of open3c ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  Win32 open3c(): **/

#elif defined(_WIN32)

#include <stdio.h> /* for sprintf */

    extern int OPEN3( const char * fname ,
                      int          fnamelen ,
                      const int  * status,
                      const char * pname,
                      int          pnamelen ) ;

    extern IOAPI_Bdesc3 BDESC3; /* JEB bdesc3 ; */
    extern IOAPI_Cdesc3 CDESC3; /* JEB cdesc3 ; */

int open3c( const char          * fname ,
            const IOAPI_Bdesc3  * bdesc ,
            const IOAPI_Cdesc3  * cdesc ,
            int                   status,
            const char          * pname )

    {       /*  begin body of open3c() */
    char nbuf[  32 ] ;
    char mbuf[ 256 ] ;

    if ( ( status == FSNEW3  ) || 
         ( status == FSUNKN3 ) ||
         ( status == FSCREA3 ) )
        {
        if ( ( ! bdesc ) || ( ! cdesc ) )
            {
            sprintf( nbuf, "%s:%s", pname, "open3c()" ) ;
            sprintf( mbuf, "%s( %s )", 
                           "Null passed to open3c", fname ) ;
            m3errc( nbuf, 0, 0, mbuf, 0 ) ;
            return( 0 ) ;
            }
    
        memcpy( (void*) &BDESC3 /* JEB &bdesc3 */, (void*) bdesc, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) &CDESC3 /* JEB &cdesc3 */, (void*) cdesc, sizeof( IOAPI_Cdesc3 ) ) ;
    
        }	/** if opened "new" or "unknown" **/

    return OPEN3(  fname  ,
                   (int) strlen( fname ) ,
                 & status ,
                   pname  ,
                   (int) strlen( pname ) ) ;

    }       /*  end body of open3c ()  */

                	/** END  CASE OF Win32 **/
                	/** NEXT CASE:  CRAY CF77-TARGETED open3c(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int OPEN3( const _fcd   fname ,
                      const  int * status,
                      const _fcd   pname ) ;

    IOAPI_Bdesc3  BDESC3 ;
    IOAPI_Cdesc3  CDESC3 ;


int open3c( const char          * fname ,
            const IOAPI_Bdesc3  * bdesc ,
            const IOAPI_Cdesc3  * cdesc ,
            int                   status,
            const char          * pname )

    {       /*  begin body of open3c() */
    
    _fcd  file ;
    _fcd  prgm ;
    
    char nbuf[  32 ] ;
    char mbuf[ 256 ] ;

    if ( ( status == FSNEW3  ) || 
         ( status == FSUNKN3 ) ||
         ( status == FSCREA3 ) )
        {
        if ( ( ! bdesc ) || ( ! cdesc ) )
            {
            sprintf( nbuf, "%s:%s", pname, "open3c()" ) ;
            sprintf( mbuf, "%s( %s )", 
                           "Null passed to open3c", fname ) ;
            m3errc( nbuf, 0, 0, mbuf, 0 ) ;
            return( 0 ) ;
            }
    
        memcpy( (void*) &BDESC3, (void*) bdesc, sizeof( IOAPI_Bdesc3 ) ) ;
        memcpy( (void*) &CDESC3, (void*) cdesc, sizeof( IOAPI_Cdesc3 ) ) ;
    
        }	/** if opened "new" or "unknown" **/

    file = _cptofcd( (char *)fname, (int) strlen( fname ) ) ;
    prgm = _cptofcd( (char *)pname, (int) strlen( pname ) ) ;

    return _btol( OPEN3( file, &status, prgm ) ) ;
                     
    }       /*  end body of open3c ()  */

                	/** END  CASE OF CRAY CF77-TARGETED open3c(): **/

#else

#error   "Error compiling open3c():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

