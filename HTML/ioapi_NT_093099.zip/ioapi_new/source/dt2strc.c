/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	format and return the date and time as a character string
C	"HH:MM:SS  M+ D+, YYYY"
C
C PRECONDITIONS:
C	valid Julian date YYYYDDD, time HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C	Revised   8/99 by CJC -- uses mmddyyc(), hhmmssc()
C
**************************************************************************/

#include  <string.h>
#include  <stdio.h>
#include  "iodecl3.h"

void   dt2strc( int         jdate ,
                int         jtime ,
                char  buffer[ 25 ] )
{

int col ;

if ( jdate > 9999999 || jdate < 0 ) 
    {
    fprintf( stderr, 
             "\n\n*** %s ***\n    %s %d\n",
             "Year-number error in dt2strc()",
             "jdate = ", jdate ) ;
    strcpy( buffer, "<DATE&TIME ERROR>" ) ;
    return ; 
    }

if ( jtime > 999999 || jtime < 0 ) 
    {
    fprintf( stderr, 
             "\n\n*** %s ***\n    %s %d\n",
             "Time-number error in dt2strc()",
             "jtime = ", jtime ) ;
    strcpy( buffer, "<DATE&TIME ERROR>" ) ;
    return ; 
    }

hhmmssc( jtime, buffer ) ;
col = strlen( buffer ) ;
buffer[ col ] = ' ' ;
mmddyyc( jdate, buffer + col + 1 ) ;

return ; 
    
}		/** END BODY OF void dt2strc() **/

