#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "parms3.h"

/** Hack for Feldman-descended f77's follows: **/

#if FLDMN 
#define         SYSTEMF   systemf_
#elif defined(__hpux) || defined(_AIX)
#define         SYSTEMF   systemf
#endif


#if defined(SYSTEMF) || defined(_WIN32)

                        /** Feldman-descended and WIN32 targets: **/

    /** -------------------- fstr2cstr() ----------------------------- **/

    static void  fstr2cstr( const char * source, 
                            char       * target, 
                            long         slen, 
                            long         tlen )
        {
        char *bound, ch ;
        long length ;

        for ( length = ( slen < tlen ? slen : tlen ) ,
              bound  = target + length ;
                  target < bound ;
                      target++ , source++ )
            {
            *target = *source ;
            }

        *target = '\0' ;

        }       /** END Feldmanish fstr2cstr() **/


    int SYSTEMF( char *cmdstr, long length )
        {
        char cmdbuf[ 4096 ] ;
        fstr2cstr( cmdstr, cmdbuf, length, 4096 ) ;
        return( system( cmdbuf ) ) ;
        }

#elif defined(_CRAY)                         /** Cray targets: **/

#include <fortran.h>

    static void  fstr2cstr( const _fcd   source, 
                            char       * target, 
                            int          tlen )
        {
        char *ptr, *bound, ch ;
        int   slen, length ;

        slen = _fcdlen( source ) ;
        tlen-- ;

        length = ( slen < tlen ? slen : tlen ) ;
        ptr    = _fcdtocp( source ) ;
        for ( bound  = ptr + length ; ptr < bound ; target++ , ptr++ )
            {
            *target = *ptr ;
            }

        *target = '\0' ;

        }           /** END Cray fstr2cstr() **/

    int SYSTEMF( const _fcd   cmdstr )
        {
        char cmdbuf[ 4096 ] ;
        fstr2cstr( cmdstr, cmdbuf, 4096 ) ;
        return( system( cmdbuf ) ) ;
        }


#else

#error   "Error compiling SYSTEMF():  unsupported architecture"

#endif

