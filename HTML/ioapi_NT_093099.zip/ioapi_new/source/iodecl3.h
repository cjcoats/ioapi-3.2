/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/************************************************************************
C  INCLUDE FILE  iodecl3.h
C
C  CONTAINS:  
C       Typedefs and prototypes of C wrappers for I/O API
C
C  DEPENDENT UPON:  
C       consistency with FORTRAN include-file IODECL3.EXT, FDESC3.EXT
C
C  REVISION HISTORY:  
C       prototype 5/9/95 by CJC
C
**************************************************************************/

#ifndef    IODECL3_DEFINED
#define    IODECL3_DEFINED


#ifdef __cplusplus
extern "C" {
#endif


#include   "parms3.h"  /*  defines FLDMN and FREAL */
#include   "fdesc3.h"

/*************************************************************************      
        Prototype declarations for public C bindings to I/O API
        In the following: 
            "fname" and "vname" are character strings of length 
            at most 16=NAMLEN3, for the file and variable names 
            respectively.
            "jdate" and "jtime" are date and time, encoded as 
            integers in the formats YYYYDDD and HHMMSS, respectively.
            "buffer" is the array (or other data structure) for the
            data being read or written.
            
**************************************************************************/

#if FLDMN && ! defined(_WIN32) /* JEB || defined(_WIN32) */

#define GCD              gcd_ 
#define GETDTTIME        getdttime_
#define POLY             poly_

#elif defined(_WIN32)			/* JEB */

#elif defined(__hpux) || defined(_AIX)

#define GCD              gcd
#define GETDTTIME        getdttime
#define POLY             poly

#elif  defined(_CRAY)

#else
 
#error   "Error compiling:  unsupported architecture"
 
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/
                                        /** I/O API functions **/
/* JEB - add section for conditional creation of DLL under Windows */
	/* to create a DLL, use a compiler setting to define MAKE_DLL
	thereby defining LINKDLL to export the function, making it available 
	to other programs */
	/* NOTE: if the dllexport is not performed, then a DLL may be
	created but the functions are not exported for use by other 
	programs */

#if defined(_WIN32)
#if defined(MAKE_DLL)
#define LINKDLL __declspec(dllexport)
#else 
#define LINKDLL __declspec(dllimport)  
#endif
#else
#define LINKDLL   
#endif

/* JEB also added LINKDLL prefix to functions here */


LINKDLL int init3c(  void ) ;                   /** start up I/O API **/

LINKDLL int shut3c(  void ) ;                   /** shut down I/O API **/

LINKDLL int open3c(  const char  * fname  ,
             const IOAPI_Bdesc3  * bdesc ,
             const IOAPI_Cdesc3  * cdesc ,
             int           status ,
             const char  * pname  ) ;   /** open file fname **/

LINKDLL int check3c( const char  * fname ,
             const char  * vname ,
             int           jdate ,
             int           jtime ) ;    /** check if vble OK for date&time **/

LINKDLL int close3c( const char  * fname ) ;    /** close file fname   **/

LINKDLL int desc3c(  const char    * fname ,
             IOAPI_Bdesc3  * bdesc ,
             IOAPI_Cdesc3  * cdesc  ) ; /** get file description for fname **/

LINKDLL int read3c(  const char  * fname ,
             const char  * vname ,
             int           layer ,
             int           jdate ,
             int           jtime ,
             void        * buffer ) ;   /** read vble(s) @ date&time  **/

LINKDLL int write3c( const char  * fname ,
             const char  * vname ,
             int           jdate ,
             int           jtime ,
             const void  * buffer ) ;   /** write vble(s) @ date&time **/

LINKDLL int xtract3c( const char  * fname , const char  * vname ,
              int           lolay , int           hilay ,
              int           lorow , int           hirow ,
              int           locol , int           hicol ,
              int           jdate , int           jtime ,
              void        * buffer ) ; /** read subwindow of grd vble **/

LINKDLL int interp3c( const char  * fname ,    /*   file  name  */
              const char  * vname ,    /*   vble  name  */
              const char  * cname ,    /*  caller name  */
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer ) ;  /** time interp of grd|bdy vble **/

LINKDLL int ddtvar3c( const char  * fname ,    /*   file  name  */
              const char  * vname ,    /*   vble  name  */
              const char  * cname ,    /*  caller name  */
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer ) ;  /** time-derivative of grd|bdy vble **/


                                        /** UTILITY functions: **/

LINKDLL int currstepc( int   jdate , int   jtime ,
               int   sdate , int   stime , int   tstep,
               int * cdate , int * ctime ) ; 
                                      /* timestep enclosing jdate:jtime */

LINKDLL void   daymonc( int   jdate ,
                int * month ,
                int * mday ) ;   /** month and day-of-month for jdate **/

LINKDLL int dscoordc( const char * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent ) ;  /** get coord sys description **/

LINKDLL int dscgridc( const char * gname ,
              char       * cname ,
              int        * ctype ,
              double     * p_alp ,
              double     * p_bet ,
              double     * p_gam ,
              double     * xcent ,
              double     * ycent ,
              double     * xorig ,
              double     * yorig ,
              double     * xcell ,
              double     * ycell ,
              int        * ncols ,
              int        * nrows ,
              int        * nthik ) ;  /** get grid description **/

LINKDLL void   dt2strc( int   jdate ,
                int   jtime ,
                char  buffer[ 25 ] ) ;  /** date-and-time to string **/

LINKDLL int envync( const char * lname       , 
            const char * description , 
            int          defaultval  ,
            int        * status );  /** Get Y-N environment-vble value **/

LINKDLL int envintc( const char * lname       ,
             const char * description ,
             int          defaultval  ,
             int        * status  ); /** Get int environment-vble value **/

LINKDLL float envrealc( const char * lname       , 
                const char * description , 
                float        defaultval  ,
                int        * status ); /** Get float env-vble value **/

LINKDLL double envdblec( const char * lname       , 
                 const char * description , 
                 double       defaultval  ,
                 int        * status ); /** Get double env-vble value **/

LINKDLL void envstrc( const char * lname       , 
              const char * description , 
              const char * defaultval  ,
              char       * evalue      ,
              int        * status      ,
              int          elen ) ; /** get string env-vble value  **/

LINKDLL int find1c( int        k1,
            int        n,
            const int *list1 ); /** look up integer in sorted key table **/

LINKDLL int find2c( int        k1,
            int        k2,
            int        n, 
            const int *list1 ,
            const int *list2 ) ; /** look up <K1,K2> in 2-key table **/

LINKDLL int find3c( int        k1,
            int        k2,
            int        k3,
            int        n, 
            const int *list1 ,
            const int *list2 ,
            const int *list3 ) ; /** look up <K1,K2,K3> in 3-key table **/

LINKDLL int find4c( int        k1,
            int        k2,
            int        k3,
            int        k4,
            int        n, 
            const int *list1 ,
            const int *list2 ,
            const int *list3 ,
            const int *list4 ) ; /* look up <K1,K2,K3,K4> in 4-key table */
 
LINKDLL int GCD( const int *p, const int *q ) ;  /** greatest common divisor **/

LINKDLL int getdfilec( const char          * fname  ,
               int                   rstatus,
               int                   fstatus,
               int                   reclen,
               const char          * pname  ) ; /** Open F. dir-acc file **/

LINKDLL int getefilec( const char          * fname  ,
               int                   rstatus,
               int                   fstatus,
               const char          * pname  ) ; /** Open F. seq file **/

LINKDLL void  GETDTTIME ( int * now_date, 
                int * now_time ) ;      /** Current wall-clock time **/

LINKDLL void   hhmmssc( int   jtime ,
                char  buffer[ 11 ] ) ;  /** time to string "hh:mm"ss" **/       

LINKDLL int    julianc( int   year  ,
                int   month ,
                int   mday ) ;    /** day 1...365,6 for indicated date **/

LINKDLL void m3errc( const char * caller ,
             int          jdate ,
             int          jtime ,    /** error/warning message with        **/
             const char * errtxt ,   /** optional shutdown of I/O API and  **/
             int          fatal ) ;  /** program termination by exit( 2 )  **/

LINKDLL void m3exitc( const char * caller ,
              int          jdate  ,
              int          jtime  ,    /** error message with shutdown of   **/
              const char * errtxt ,    /** I/O API and program termination  **/
              int          errstat ) ; /** by exit( errstat )               **/

LINKDLL void m3mesgc( const char * mesg ) ;   /** write mesg to the Fortran-pgm log **/

LINKDLL void m3warnc( const char * caller ,   /** Warning mesg to Fortran-pgm log **/
              int          jdate ,
              int          jtime ,
              const char * errtxt );

LINKDLL void   mmddyyc( int   jdate ,
                char  buffer[ 15 ] ) ;  /** date to string "Month DD, YYYY" **/

LINKDLL void NAMEVAL 
	(char * lname, int llen, char * eqname, int elen);

LINKDLL void  nextimec( int * jdate ,
                int * jtime ,
                int   tstep ) ;  /** Update jdate:jtime by tstep **/
                
LINKDLL float POLY( const float *x,
            const float *xpts,
            const float *ypts,
            const int   *deg ) ;  /** polynomial interpolation **/

LINKDLL void qsorti1( int        n,          /** number of elements             **/
              int        ind[],      /** index-array                    **/
              const int  tbl1[] ) ;  /** first  key-component in tuple  **/

LINKDLL void qsorti2( int        n,           /** number of elements             **/
              int        ind[],       /** index-array                    **/
              const int  tbl1[],      /** first  key-component in tuple  **/
              const int  tbl2[] ) ;   /** second key-component in tuple  **/

LINKDLL void qsorti3( int        n,           /** number of elements             **/
              int        ind[],       /** index-array                    **/
              const int  tbl1[],      /** first  key-component in tuple  **/
              const int  tbl2[],      /** second key-component in tuple  **/
              const int  tbl3[] ) ;   /** third  key-component in tuple  **/

LINKDLL void qsorti4( int        n,           /** number of elements             **/
              int        ind[],       /** index-array                    **/
              const int  tbl1[],      /** first  key-component in tuple  **/
              const int  tbl2[],      /** second key-component in tuple  **/
              const int  tbl3[],      /** third  key-component in tuple  **/
              const int  tbl4[] ) ;   /** fourth key-component in tuple  **/

LINKDLL int  sec2timec( int  seconds ) ;  /** convert seconds to HHMMSS **/

LINKDLL int  secsdiffc( int  adate ,
                int  atime ,
                int  zdate ,
                int  ztime ) ;    /** time difference from a* to z*  **/

LINKDLL int  time2secc( int  atime ) ;   /** HHMMSS ~~> seconds **/
               
LINKDLL int     wkdayc( int  jdate ) ;   /** day of week 1...7 for jdate **/

LINKDLL int ENVYN( const char * lname, 
           int          llen, 
           const char * descrip, 
           int          dlen,
           const int  * defaultval,
           int        * status);			/* JEB */

LINKDLL int ENVINT( const char * lname, 
            int          llen, 
            const char * descrip, 
            int          dlen,
            const int  * defaultval,
            int        * status);			/* JEB */

LINKDLL float ENVREAL( const char  * lname, 
               int           llen, 
               const char  * descrip, 
               int           dlen,
               const float * defaultval,
               int         * status);		/* JEB */

LINKDLL double ENVDBLE( const char   * lname, 
                int            llen, 
                const char   * descrip, 
                int            dlen,
                const double * defaultval,
                int          * status);		/* JEB */

LINKDLL void ENVSTR( const char * lname, 
             int          namlen, 
             const char * description, 
             int          deslen, 
             const char * defaultval, 
             int          deflen, 
             char       * eqname, 
             int          eqlen,
             int        * status);			/* JEB */








#ifdef __cplusplus
}
#endif


#endif    /*   IODECL3_DEFINED  */

/****************   END   iodecl3.h   ***********************************/


