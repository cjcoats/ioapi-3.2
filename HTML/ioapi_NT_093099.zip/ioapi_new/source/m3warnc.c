/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Generate simple warning messages for Models-3 core
C
C PRECONDITIONS:
C	JDATE:JTIME represented as YYYYDDD:HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 4/95 by CJC
C	Version   8/99 by CJC:  FLDMN, Win32
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)
#define M3WARN m3warn_
#elif defined(__hpux) || defined(_AIX)
#define M3WARN m3warn
#endif


#if defined(M3WARN)

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern void M3WARN( const char * caller ,
                        const int  * jdate ,
                        const int  * jtime ,
                        const char * errtxt ,
                        int          clen ,
                        int          elen ) ;

void m3warnc( const char          * caller ,
              int                   jdate ,
              int                   jtime ,
              const char          * errtxt )

    {       /*  begin body of m3warnc() */
    M3WARN( caller, &jdate, &jtime, errtxt,
            strlen( caller ) , strlen( errtxt ) ) ;
    return ;
    }       /*  end body of m3warnc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                	/** NEXT CASE:  WIN32 m3warnc(): **/

#elif defined(_WIN32)

    extern void M3WARN( const char * caller ,
                        int          clen ,
                        const int  * jdate ,
                        const int  * jtime ,
                        const char * errtxt ,
                        int          elen ) ;

void m3warnc( const char          * caller ,
              int                   jdate ,
              int                   jtime ,
              const char          * errtxt )

    {       /*  begin body of m3warnc() */
    M3WARN( caller, strlen( caller ), &jdate, &jtime,
            errtxt, strlen( errtxt ) ) ;
    return ;
    }       /*  end body of m3warnc ()  */

                        /** END  CASE OF WIN32 **/
                	/** NEXT CASE:  CRAY CF77-TARGETED m3warnc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern void M3WARN( const _fcd   caller , 
                        const  int * jdate  ,
                        const  int * jtime  ,
                        const _fcd   errtxt ) ;

void m3warnc( const char          * caller ,
              int                   jdate  ,
              int                   jtime  ,
              const char          * errtxt )

    {       /*  begin body of m3warnc() */
    
    _fcd  cname ;
    _fcd  etext ;
    
    cname = _cptofcd( (char *)caller, strlen( caller ) ) ;
    etext = _cptofcd( (char *)errtxt, strlen( errtxt ) ) ;

    M3WARN( cname, &jdate, &jtime, etext ) ;
    return ;
                     
    }       /*  end body of m3warnc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED m3warnc(): **/

#else

#error   "Error compiling m3warnc():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

