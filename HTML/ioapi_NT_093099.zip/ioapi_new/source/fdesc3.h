
/************************************************************************
C  INCLUDE FILE  fdesc3.h
C
C  CONTAINS:  
C       File description typedefs for C bindings to the I/O API
C
C  DEPENDENT UPON:  
C       consistency with FORTRAN include-files PARMS33.EXT, FDESC3.EXT
C
C  REVISION HISTORY:  
C       prototype 5/9/95 by CJC
C
**************************************************************************/

#ifndef    FDESC3_DEFINED
#define    FDESC3_DEFINED

#include   "parms3.h"

/*************************************************************************      
        Typedef for I/O API file description:  same memory layout
        as the Fortran COMMONs BDESC3 and CDESC3.
**************************************************************************/

typedef char   M3Name[ NAMLEN3 ] ; /* Models3 Fortran "name" objects  */
typedef char   M3Line[ MXDLEN3 ] ; /* ... "description-line" objects  */

typedef struct { 
  double p_alp ;   /*  first, second, third map */  
  double p_bet ;   /*  projection descriptive   */  
  double p_gam ;   /*  parameters.              */  
  double xcent ;   /*  lon for coord-system X=0 */  
  double ycent ;   /*  lat for coord-system Y=0 */  
  double xorig ;   /*  X-coordinate origin of grid (map units) */
  double yorig ;   /*  Y-coordinate origin of grid  */  
  double xcell ;   /*  X-coordinate cell dimension  */  
  double ycell ;   /*  Y-coordinate cell dimension  */
  int    ftype ;   /*  file type                    */  
  int    cdate ;   /*  creation date   YYYYDDD      */  
  int    ctime ;   /*  creation time    HHMMSS      */  
  int    wdate ;   /*  update date     YYYYDDD      */  
  int    wtime ;   /*  update time      HHMMSS      */  
  int    sdate ;   /*  file start date YYYYDDD      */  
  int    stime ;   /*  file start time  HHMMSS      */  
  int    tstep ;   /*  file time step   HHMMSS      */  
  int    mxrec ;   /*  max time step record number  */  
  int    nvars ;   /*  number of species            */  
  int    ncols ;   /*  number of grid columns       */  
  int    nrows ;   /*  number of grid rows          */  
  int    nlays ;   /*  number of layers             */  
  int    nthik ;   /*  BOUNDARY:  perimeter thickness (cells)  */  
  int    gdtyp ;   /*  grid type:  1=LAT-LON, 2=LAM, ...       */  
  int    vgtyp ;   /*  vertical coordinate type (VGSIGP3, ...) */
  FREAL  vgtop ;   /*  model-top, for sigma coord types.       */  
  FREAL  vglvs[ MXLAYS3 + 1 ] ;  /*  vertical coord values.    */ 
  int    vtype[ MXVARS3 ] ;      /* basic data type M3INT, ... */
}
IOAPI_Bdesc3 ;

typedef struct { 
  M3Name  gdnam ;  /* grid name                       */ 
  M3Name  upnam ;  /* last program writing to file    */ 
  M3Line  execn ;  /* value of env vble EXECUTION_ID  */ 
  M3Line  fdesc[ MXDESC3 ] ; /* file description      */ 
  M3Line  updsc[ MXDESC3 ] ; /* update   "            */
  M3Name  vname[ MXVARS3 ] ; /* variable names        */
  M3Name  units[ MXVARS3 ] ; /*   "      units        */
  M3Line  vdesc[ MXVARS3 ] ; /*   "      descriptions */
}
IOAPI_Cdesc3 ;


#endif    /*   FDESC3_DEFINED  */

/****************   END   fdesc3.h   ***********************************/


