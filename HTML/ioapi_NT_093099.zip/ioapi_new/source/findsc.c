/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
PURPOSE
        Return subscript at which integer entry found in SORTED 
        key-tables -- versions for single-key through quadruple-key
        tables, 
        Returns negative number in case of failure.

PRECONDITIONS
        
        Sorted tables list<n>

CALLS
        none

REVISION HISTORY
        prototype  3/95 by CJC
                    
**************************************************************************/

#include  "parms3.h"
#include  "iodecl3.h"

#if FLDMN && !defined(_WIN32) /* JEB */

#define  FIND1  find1_
#define  FIND2  find2_
#define  FIND3  find3_
#define  FIND4  find4_

#define  FINDR1  findr1_
#define  FINDR2  findr2_
#define  FINDR3  findr3_
#define  FINDR4  findr4_

#elif defined(__hpux) || defined(_AIX)

#define  FIND1  find1
#define  FIND2  find2
#define  FIND3  find3
#define  FIND4  find4

#define  FINDR1  findr1
#define  FINDR2  findr2
#define  FINDR3  findr3
#define  FINDR4  findr4

#elif  defined(_CRAY) || defined(_WIN32)

#else
 
#error   "Error compiling findsc():  unsupported architecture"
 
#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/
                                        /** I/O API functions **/


    extern int FIND1( int  *k1, 
                      int  *n , 
                      const int *list1 ) ;

    extern int FIND2( int  *k1, 
                      int  *k2, 
                      int  *n , 
                      const int *list1 ,
                      const int *list2 ) ;

    extern int FIND3( int  *k1, 
                      int  *k2, 
                      int  *k3, 
                      int  *n , 
                      const int *list1 ,
                      const int *list2 ,
                      const int *list3 ) ;

    extern int FIND4( int  *k1, 
                      int  *k2, 
                      int  *k3, 
                      int  *k4, 
                      int  *n , 
                      const int *list1 ,
                      const int *list2 ,
                      const int *list3 ,
                      const int *list4 ) ;

    extern int FINDR1( FREAL *k1, 
                       int   *n , 
                       const FREAL *list1 ) ;

    extern int FINDR2( FREAL *k1, 
                       FREAL *k2, 
                       int   *n , 
                       const FREAL *list1 ,
                       const FREAL *list2 ) ;

    extern int FINDR3( FREAL *k1, 
                       FREAL *k2, 
                       FREAL *k3, 
                       int   *n , 
                       const FREAL *list1 ,
                       const FREAL *list2 ,
                       const FREAL *list3 ) ;

    extern int FINDR4( FREAL *k1, 
                       FREAL *k2, 
                       FREAL *k3, 
                       FREAL *k4, 
                       int   *n , 
                       const FREAL *list1 ,
                       const FREAL *list2 ,
                       const FREAL *list3 ,
                       const FREAL *list4 ) ;


int find1c( int        k1,      /** first  key component **/
            int        n,       /** table size **/
            const int *list1 )  /** first  key table **/
    {
    return -1 + FIND1( &k1, &n, list1 ) ;
    }                           /*  end body of find1c()  */

int find2c( int        k1,      /** first  key component **/
            int        k2,      /** second key component **/
            int        n,       /** table size **/
            const int *list1 ,  /** first  key table **/
            const int *list2 )  /** second key table **/
    {
    return -1 + FIND2( &k1, &k2, &n, list1, list2 ) ;
    }                           /*  end body of find2c()  */

int find3c( int        k1,      /** first  key component **/
            int        k2,      /** second key component **/
            int        k3,      /** third  key component **/
            int        n,       /** table size **/
            const int *list1 ,  /** first  key table **/
            const int *list2 ,  /** second key table **/
            const int *list3 )  /** third  key table **/
    {
    return -1 + FIND3( &k1, &k2, &k3, &n, list1, list2, list3 ) ;
    }                           /*  end body of find3c()  */

int find4c( int        k1,      /** first  key component **/
            int        k2,      /** second key component **/
            int        k3,      /** third  key component **/
            int        k4,      /** fourth key component **/
            int        n,       /** table size **/
            const int *list1 ,  /** first  key table **/
            const int *list2 ,  /** second key table **/
            const int *list3 ,  /** third  key table **/
            const int *list4 )  /** fourth key table **/
    {
    return -1 + FIND4( &k1, &k2, &k3, &k4, &n, list1, list2, list3, list4 ) ;
    }                           /*  end body of find4c()  */


int findr1c( FREAL        k1,      /** first  key component **/
             int          n,       /** table size **/
             const FREAL *list1 )  /** first  key table **/
    {
    return -1 + FINDR1( &k1, &n, list1 ) ;
    }                           /*  end body of findr1c()  */

int findr2c( FREAL        k1,      /** first  key component **/
             FREAL        k2,      /** second key component **/
             int          n,       /** table size **/
             const FREAL *list1 ,  /** first  key table **/
             const FREAL *list2 )  /** second key table **/
    {
    return -1 + FINDR2( &k1, &k2, &n, list1, list2 ) ;
    }                           /*  end body of findr2c()  */

int findr3c( FREAL        k1,      /** first  key component **/
             FREAL        k2,      /** second key component **/
             FREAL        k3,      /** third  key component **/
             int          n,       /** table size **/
             const FREAL *list1 ,  /** first  key table **/
             const FREAL *list2 ,  /** second key table **/
             const FREAL *list3 )  /** third  key table **/
    {
    return -1 + FINDR3( &k1, &k2, &k3, &n, list1, list2, list3 ) ;
    }                           /*  end body of findr3c()  */

int findr4c( FREAL        k1,      /** first  key component **/
             FREAL        k2,      /** second key component **/
             FREAL        k3,      /** third  key component **/
             FREAL        k4,      /** fourth key component **/
             int          n,       /** table size **/
             const FREAL *list1 ,  /** first  key table **/
             const FREAL *list2 ,  /** second key table **/
             const FREAL *list3 ,  /** third  key table **/
             const FREAL *list4 )  /** fourth key table **/
    {
    return -1 + FINDR4( &k1, &k2, &k3, &k4, &n, list1, list2, list3, list4 ) ;
    }                           /*  end body of findr4c()  */


