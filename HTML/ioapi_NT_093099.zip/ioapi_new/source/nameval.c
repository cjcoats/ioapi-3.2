/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1999 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/
    /***************************************************************/
    /**  void nameval():  FORTRAN-callable shell around getenv()  **/
    /**                                                           **/
    /**  ---->  MACHINE-DEPENDENT !! <----                        **/
    /**                                                           **/
    /**  find the value of shell variable lname in the environment**/
    /**  and return it in eqname                                  **/
    /**                                                           **/
    /**  PRECONDITIONS:  len(lname) < BUFLEN = 80.                **/
    /**                  case sensitivity handled correctly       **/
    /**                                                           **/
    /***************************************************************/

#include <stdio.h>
#include "parms3.h"
#include "iodecl3.h"	/* JEB */

#define  BUFLEN  256

                /** CODE DEPENDS (BADLY) UPON HOW THE FORTRAN    **/
                /** COMPILER DEALS WITH NAMES AND WITH CHARACTER **/
                /** STRINGS:  2-CASES HERE:  FELDMAN-DESCENDED   **/
                /** F77'S, AND CRAY CF77'S TARGETED AS CALLERS   **/
                /** OF NAMEVAL().  FIRST CASE:  FELDMANISMS:     **/

#if defined(__hpux) || defined(_AIX)  /** Hack for HP, IBM f77's follows: **/

#define NAMEVAL nameval

#elif FLDMN && !defined(_WIN32)

#define NAMEVAL nameval_

#endif


#if defined(NAMEVAL)

void NAMEVAL ( char * lname, char * eqname, int llen, int elen )
    {
    char *getenv();

    char buffer[ BUFLEN ] ;
    char *source, *target , *bound, *limit, ch ;
    int length ;

        /** COPY  lname  INTO  buffer[]  AS A C-STRING **/
        /** TRIM TRAILING BLANKS, AND ADD TERMINAL NULL **/
        /** FOR VMS, UPCASE AS YOU GO **/

    source = lname ;
    length = llen ;
    target = buffer ;
    bound  = target + ( length < BUFLEN-1 ? length : BUFLEN-1 ) ;
    for ( ; target < bound ; target++ , source++ )
        {
        ch = *source ;
        if ( ch == ' ' ) 
            {
            break ;
            } /**  END IF-CLAUSE:  BLANK CHARACTER **/
        else *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/

        *target = '\0' ; 


        /** COPY VALUE FROM ENVIRONMENT INTO CONTENTS OF eqname **/

    target = eqname ;
    bound  = target + elen ;
    if ( source = getenv( buffer ) )
        {
        for (   ; *target = *source ; target++ , source++ )
            {
            if ( target >= bound ) break ;
            }   /** END FOR-LOOP copying value from environment to eqname **/

        } /**  END IF-CLAUSE:  getenv() succeeded**/
    else
        {
        source = lname ;
        limit  = target + llen ;
        limit  = ( limit < bound ? limit : bound ) ;
        for (  ; target < limit ; *target++ = *source++ )  ; /** EMPTY BODY **/

        } /**  END END ELSE-CLAUSE:  getenv() failed **/

        /** PAD FORTRAN OUTPUT STRING WITH TRAILING BLANKS:  **/

    for (   ; target < bound ; target++ )  *target = ' ' ;

    } /**  END void function nameval() **/



                /** END  CASE OF FELDMAN-DESCENDED F77 TARGETS FOR USE   **/
                /** NEXT CASE:  WIN32 NAMEVAL(): **/


#elif  defined(_WIN32)

#include <stdlib.h>
void NAMEVAL ( char * lname, int llen, char * eqname, int elen )
    {
    char buffer[ BUFLEN ] ;
    char *source, *target , *bound, *limit, ch ;
    int length ;

        /** COPY  lname  INTO  buffer[]  AS A C-STRING **/
        /** TRIM TRAILING BLANKS, AND ADD TERMINAL NULL **/
        /** FOR VMS, UPCASE AS YOU GO **/

    source = lname ;
    length = llen ;
    target = buffer ;
    bound  = target + ( length < BUFLEN-1 ? length : BUFLEN-1 ) ;
    for ( ; target < bound ; target++ , source++ )
        {
        ch = *source ;
        if ( ch == ' ' ) 
            {
            break ;
            } /**  END IF-CLAUSE:  BLANK CHARACTER **/
        else *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/

        *target = '\0' ; 


        /** COPY VALUE FROM ENVIRONMENT INTO CONTENTS OF eqname **/

    target = eqname ;
    bound  = target + elen ;
    if ( source = getenv( buffer ) )
        {
        for (   ; *target = *source ; target++ , source++ )
            {
            if ( target >= bound ) break ;
            }   /** END FOR-LOOP copying value from environment to eqname **/

        } /**  END IF-CLAUSE:  getenv() succeeded**/
    else
        {
        source = lname ;
        limit  = target + llen ;
        limit  = ( limit < bound ? limit : bound ) ;
        for (  ; target < limit ; *target++ = *source++ )  ; /** EMPTY BODY **/

        } /**  END END ELSE-CLAUSE:  getenv() failed **/

        /** PAD FORTRAN OUTPUT STRING WITH TRAILING BLANKS:  **/

    for (   ; target < bound ; target++ )  *target = ' ' ;

    } /**  END void function nameval() **/


                /** END  CASE:  WIN32 NAMEVAL(): **/
                /** NEXT CASE:  CRAY CF77-TARGETED NAMEVAL(): **/

#elif  defined(_CRAY)


#include <fortran.h>

void NAMEVAL ( _fcd lname, _fcd eqname )
    {
    char *getenv();

    char buffer[ BUFLEN ] ;
    char *source, *target , *bound, *limit, ch ;
    int length ;

        /** COPY  lname  INTO  buffer[]  AS A C-STRING **/
        /** TRIM TRAILING BLANKS, AND ADD TERMINAL NULL **/
        /** FOR VMS, UPCASE AS YOU GO **/

    source = _fcdtocp( lname ) ;
    length = _fcdlen( lname ) ;
    target = buffer ;
    bound  = target + ( length < BUFLEN-1 ? length : BUFLEN-1 ) ;
    for ( ; target < bound ; target++ , source++ )
        {
        ch = *source ;
        if ( ch == ' ' ) 
            {
            break ;
            } /**  END IF-CLAUSE:  BLANK CHARACTER **/
        else *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/

        *target = '\0' ; 


        /** COPY VALUE FROM ENVIRONMENT INTO CONTENTS OF eqname **/

    target = _fcdtocp( eqname ) ;
    bound  = target + _fcdlen( eqname ) ;
    if ( source = getenv( buffer ) )
        {
        for (   ; *target = *source ; target++ , source++ )
            {
            if ( target >= bound ) break ;
            }   /** END FOR-LOOP copying value from environment to eqname **/

        } /**  END IF-CLAUSE:  getenv() succeeded**/
    else
        {
        source = _fcdtocp(  lname ) ;
        limit  = target + ( _fcdlen( lname ) ) ;
        limit  = ( limit < bound ? limit : bound ) ;
        for (  ; target < limit ; *target++ = *source++ )  ; /** EMPTY BODY **/

        } /**  END END ELSE-CLAUSE:  getenv() failed **/

        /** PAD FORTRAN OUTPUT STRING WITH TRAILING BLANKS:  **/

    for (   ; target < bound ; target++ )  *target = ' ' ;

    } /**  END void function nameval() **/


                /** END CASE OF NAMEVAL() FOR CRAY             **/
                /** REMAINING CASE:  UNSUPPORTED ARCHITECTURES **/
                /** ABORT THE COMPILATION FOR THEM             **/

#else

#error   "Error compiling NAMEVAL():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

