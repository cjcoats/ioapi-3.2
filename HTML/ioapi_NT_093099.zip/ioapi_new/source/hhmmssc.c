/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	format and return the time as a character string
C	"HH:MM:SS  M+ D+, YYYY"
C
C PRECONDITIONS:
C	valid time HHMMSS
C
C CALLS:
C	none
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  <stdio.h>
#include  "iodecl3.h"

void   hhmmssc( int   jtime ,
                char  buffer[ 11 ] )
{
int   hour, mins, secs ;

if ( jtime > 999999 || jtime < 0 ) 
    {
    fprintf( stderr, 
             "\n\n*** %s ***\n    %s %d\n",
             "Time-number error in dt2strc()",
             "jtime = ", jtime ) ;
    strcpy( buffer, "<TIMERROR>" ) ;
    return ;
    }

hour = jtime ;
secs = hour % 100 ;
hour = hour / 100 ;
mins = hour % 100 ;
hour = hour / 100 ;

sprintf( buffer, "%02d:%02d:%02d\0", hour , mins , secs ) ;
return ;
    
}		/** END BODY OF void hhmmssc() **/

