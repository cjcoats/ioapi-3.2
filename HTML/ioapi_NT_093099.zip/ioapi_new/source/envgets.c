                
/**********************************************************************
 LOGICAL     ENVYN()   and  int    envync()
 INTEGER     ENVINT()  and  int    envintc()
 REAL        ENVREAL() and  float  envrealc()
 DOUBLE      ENVDBLE() and  double envdblec()
 SUBROUTINE  ENVSTR()  and  void   envstrc()
 LOGICAL     SETENV()
    
      ---->  MACHINE-DEPENDENT !! <----

  find the value of shell variable lname in the environment,
  convert it to the indicated type, and return it

  PRECONDITIONS:  len(lname), len(description) < BUFLEN = 256.
                  case sensitivity handled correctly

  C                     bindings start at line   39
        envync()   at line   54
        envintc()  at line  136
        envrealc() at line  192
        envdblec() at line  248
        envstrc()  at line  302
  Feldman-style Fortran bindings start at line  371
        ENVYN()    at line  475
        ENVINT()   at line  497
        ENVREAL()  at line  519
        ENVDBLE()  at line  541
        ENVSTR()   at line  563
        SETENV()   at line  593
  Cray-style    Fortran bindings start at line  622
        ENVYN()    at line  707
        ENVINT()   at line  730
        ENVREAL()  at line  748
        ENVDBLE()  at line  768
        ENVSTR()   at line  787
        SETENV()   at line  815

**********************************************************************/

#include "iodecl3.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
                  
#define  BUFLEN  512


/** ----------------------------------------------------------------- **/
/** ---------------------- C  bindings ------------------------------ **/
/** ----------------------------------------------------------------- **/
/** -----------------------------  envync()  ------------------------ **/

int envync( const char * lname       , 
            const char * description , 
            int          defaultval ,
            int        * status )
    {
    char  *evalue ;
    char   value, ch ;
    char   mesg[ BUFLEN ] ;
    
    if ( evalue = getenv( lname ) )
        {
        if ( value = *evalue )
            {
            if ( value == '.' ) 
                {
                ch = evalue[ 1 ] ;
                if( islower( ch ) ) ch = toupper( ch ) ;
                }
            if( islower( value ) ) 
                {
                value = toupper( value ) ;
                }

            if ( value == 'Y' || value == 'T' )
                {
                sprintf( mesg,
                         "%s %s:  %s %s",                            
                         "Value for", lname, evalue, "returning TRUE" ) ;
                m3mesgc( mesg ) ;
                *status = 0 ;
                return 1 ;
                }
            else if ( value == 'N' || value == 'F' )
                {
                sprintf( mesg,
                         "%s %s:  %s %s",                            
                         "Value for", lname, evalue, "returning FALSE" ) ;
                m3mesgc( mesg ) ;
                *status = 0 ;
                return 0 ;
                }
            else{
                sprintf( mesg, 
                         "%s %s %s: '%.16s', %s  %s",
                         "Value for",  lname, "not T,F,Y, or N", evalue, 
                         "returning defaultval  ",
                         defaultval ? "TRUE" : "FALSE" ) ;
                m3errc( "envync", 0, 0, mesg, 0 ) ;
                *status = 1 ;
                return defaultval ;
                }                       /** END:  strtol() failure **/
            }                           /** END:  lname defined      **/
        else{                           /** ELSE  lname defined but empty  **/
            sprintf( mesg,
                     "%s %s %s:  %s",                            
                     "Value for", lname, 
                     "defined but empty; returning default",
                     defaultval ? "TRUE" : "FALSE" ) ;
            m3mesgc( mesg ) ;
            *status = -1 ;
            return defaultval  ;
            }                           /** END:  lname defined but empty **/
        }                       /** END:  lname defined     **/
    else{                       /** ELSE  lname not defined **/
        sprintf( mesg,
                 "%s %s %s  %s",                            
                 "Value for", lname, 
                 "not defined;returning default:", 
                 defaultval ? "TRUE" : "FALSE" ) ;
        m3mesgc( mesg ) ;
        *status = -2 ;
        return defaultval ;
        }                       /** END:  lname defined or not **/
    }   /** end int envync() **/


/** -----------------------  envintc()  -------------------------- **/

int envintc( const char *lname,
             const char *description,
             int         defaultval ,
             int        *status )
    {
    char  *evalue, *end ;
    int    value ;
    char   mesg[ BUFLEN ] ;
    
    if ( evalue = getenv( lname ) )
        {
        if ( *evalue )                  /** lname defined **/
            {
            value = (int)strtol( evalue, &end, 10 ) ;
            if ( evalue == end )        /** strtol() failure **/
                {
                sprintf( mesg, 
                         "%s %s %s: '%.16s', %s  %d",
                         "Value for",  lname, "not an integer", evalue, 
                         "returning default", defaultval ) ;
                m3errc( "envintc", 0, 0, mesg, 0 ) ;
                *status = 1 ;
                return defaultval ;
                }                       /** END:  strtol() failure **/
            else{                       /** ELSE: strtol() success **/
                sprintf( mesg,
                         "%s %s:  %d",                            
                         "Value for", lname, value ) ;
                m3mesgc( mesg ) ;
                *status = 0 ;
                return value ;
                }                       /** END:  strtol() success   **/
            }                           /** END:  lname defined      **/
        else{                           /** ELSE  lname defined but empty  **/
            sprintf( mesg,
                     "%s %s %s:  %d",                            
                     "Value for", lname, 
                     "defined but empty; returning default", defaultval ) ;
            m3mesgc( mesg ) ;
            *status = -1 ;
            return defaultval  ;
            }                           /** END:  lname defined but empty **/
        }                       /** END:  lname defined     **/
    else{                       /** ELSE  lname not defined **/
        sprintf( mesg,
                 "%s %s %s:  %d",                            
                 "Value for", lname, 
                 "not defined; returning default", defaultval ) ;
        m3mesgc( mesg ) ;
        *status = -2 ;
        return defaultval ;
        }                       /** END:  lname defined or not **/
    }   /** end int envintc() **/


/** ----------------------------  envrealc()  --------------------- **/
float envrealc( const char *lname, 
                const char *description, 
                float       defaultval,
                int        *status )
    {
    char  *evalue, *end ;
    float  value ;
    char   mesg[ BUFLEN ] ;
    
    if ( evalue = getenv( lname ) )
        {
        if ( *evalue )                  /** lname defined **/
            {
            value = (float)strtod( evalue, &end ) ;
            if ( evalue == end )        /** strtol() failure **/
                {
                sprintf( mesg, 
                         "%s %s %s: '%.16s', %s  %f",
                         "Value for",  lname, "not a real", evalue, 
                         "returning default", defaultval ) ;
                m3errc( "envrealc", 0, 0, mesg, 0 ) ;
                *status = 1 ;
                return defaultval ;
                }                       /** END:  strtol() failure **/
            else{                       /** ELSE: strtol() success **/
                sprintf( mesg,
                         "%s %s:  %f",                            
                         "Value for", lname, value ) ;
                m3mesgc( mesg ) ;
                *status = 0 ;
                return value ;
                }                       /** END:  strtol() success   **/
            }                           /** END:  lname defined      **/
        else{                           /** ELSE  lname defined but empty  **/
            sprintf( mesg,
                     "%s %s %s:  %f",                            
                     "Value for", lname, 
                     "defined but empty; returning default", defaultval ) ;
            m3mesgc( mesg ) ;
            *status = -1 ;
            return defaultval  ;
            }                           /** END:  lname defined but empty **/
        }                       /** END:  lname defined     **/
    else{                       /** ELSE  lname not defined **/
        sprintf( mesg,
                 "%s %s %s:  %f",                            
                 "Value for", lname, 
                 "not defined; returning default", defaultval ) ;
        m3mesgc( mesg ) ;
        *status = -2 ;
        return defaultval ;
        }                       /** END:  lname defined or not **/
    }   /** end int envrealc() **/


/** -------------------------------  envdblec()  --------------------- **/
double envdblec( const char  *lname, 
                 const char  *description, 
                 double       defaultval ,
                 int         *status)
    {
    char   *evalue, *end ;
    double  value ;
    char    mesg[ BUFLEN ] ;
    
    if ( evalue = getenv( lname ) )
        {
        if ( *evalue )                  /** lname defined **/
            {
            value = strtod( evalue, &end ) ;
            if ( evalue == end )        /** strtod() failure **/
                {
                sprintf( mesg, 
                         "%s %s %s: '%.16s', %s  %lf",
                         "Value for",  lname, "not a double", evalue, 
                         "returning default:", defaultval ) ;
                m3errc( "envdblec", 0, 0, mesg, 0 ) ;
                *status = 1 ;
                return defaultval ;
                }                       /** END:  strtod() failure **/
            else{                       /** ELSE: strtod() success **/
                sprintf( mesg,
                         "%s %s:  %lf",                            
                         "Value for", lname, value ) ;
                m3mesgc( mesg ) ;
                *status = 0 ;
                return value ;
                }                       /** END:  strtod() success   **/
            }                           /** END:  lname defined      **/
        else{                           /** ELSE  lname defined but empty  **/
            sprintf( mesg,
                     "%s %s %s:  %lf",                            
                     "Value for", lname, 
                     "defined but empty; returning default", defaultval ) ;
            m3mesgc( mesg ) ;
            *status = -1 ;
            return defaultval  ;
            }                           /** END:  lname defined but empty **/
        }                       /** END:  lname defined     **/
    else{                       /** ELSE  lname not defined **/
        sprintf( mesg,
                 "%s %s %s:  %lf",                            
                 "Value for", lname, 
                 "not defined;returning default", defaultval ) ;
        m3mesgc( mesg ) ; 
        *status = -2 ;
        return defaultval ;
        }                       /** END:  lname defined or not **/
    }   /** end int envdblec() **/


/** -------------------------------------------------------------- **/

void envstrc( const char * lname, 
              const char * description, 
              const char * defaultval,
              char       * evalue,
              int        * status,
              int          elen )
    {
    char   mesg[ BUFLEN ] ;
    char  *value ;
    size_t length ;
    
    if ( value = getenv( lname ) )
        {
        if ( *value )                  /** lname defined **/
            {
            strncpy( evalue, value, elen ) ;
            sprintf( mesg,
                     "%s %s:  '",                            
                     "Value for", lname ) ;
            length = BUFLEN - strlen( mesg ) - 2 ;
            length = ( length < elen ? length : elen ) ;
            strncat( mesg, evalue, length ) ;
            strncat( mesg, "'", (size_t)1 ) ;
            *status = 0 ;
            }
        else{
            strncpy( evalue, defaultval, elen ) ;
            sprintf( mesg,
                     "%s %s %s:  '",                            
                     "Value for", lname, 
                     "defined but empty; returning default '" ) ;
            length = BUFLEN - strlen( mesg ) - 2 ;
            length = ( length < elen ? length : elen ) ;
            strncat( mesg, evalue, length ) ;
            strncat( mesg, "'", (size_t)1 ) ;
            *status = -1 ;
            }                           /** END:  lname defined but empty **/
        }                       /** END:  lname defined     **/
    else{                       /** ELSE  lname not defined **/
        strncpy( evalue, defaultval, elen ) ;
        sprintf( mesg,
                 "%s %s %s:  '",                            
                 "Value for", lname, 
                 "not defined; returning defaultval '" ) ;
        length = BUFLEN - strlen( mesg ) - 2 ;
        length = ( length < elen ? length : elen ) ;
        strncat( mesg, evalue, length ) ;
        strncat( mesg, "'", (size_t)1 ) ;
        *status = -2 ;
        }                       /** END:  lname defined or not **/

    m3mesgc( mesg ) ;
    return ;

    }   /** end int envstrc() **/


/** -------------------------------------------------------------- **/
/** ---------------------- Fortran bindings ---------------------- **/
/** -------------------------------------------------------------- **/
/** CODE DEPENDS (BADLY) UPON HOW THE FORTRAN COMPILER DEALS WITH  **/
/** NAMES AND WITH CHARACTER STRINGS:                              **/
/** 3-CASES HERE:  FELDMAN-DESCENDED F77'S, WIN32 F77'S,           **/
/** AND CRAY CF77'S TARGETED AS CALLERS OF ENV*().                 **/
/** -------------------------------------------------------------- **/
/** FIRST CASE:  FELDMANISMS:                                    **/


#if FLDMN && !defined(_WIN32)

/** Hack for Feldman-descended f77's follows: **/

#define ENVYN   envyn_
#define ENVINT  envint_
#define ENVREAL envreal_
#define ENVDBLE envdble_
#define ENVSTR  envstr_
#define SETENV  setenv_

#elif defined(__hpux) || defined(_AIX)

/** Hack for Feldman-descended f77's follows: **/

#define ENVYN   envyn
#define ENVINT  envint
#define ENVREAL envreal
#define ENVDBLE envdble
#define ENVSTR  envstr
#define SETENV  setenv

#endif

#if (FLDMN || defined(__hpux) || defined(_AIX)) && !defined(_WIN32)


/** -------------------------------------------------------------- **/
/** ------------------------  auxilliary functions  -------------- **/
/** -------------------------------------------------------------- **/
/** ----------------------  name2cstr()  ------------------------- **/

static void  name2cstr( const char * source, 
                        char       * target,
                        int          slen,
                        int          tlen )
    {
    char  *bound ;
    char   ch ;
    int    length ;
    
    tlen-- ;

    for ( length = ( slen < tlen ? slen : tlen ) ,
          bound  = target + length ;
              target < bound ;
                  target++ , source++ )
        {
        ch = *source ;
        if ( isspace( ch ) ) break ;
        *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/
    
    *target = '\0' ;
    
    }    /** END Feldmanish name2cstr() **/
    

/** -------------------- fstr2cstr() ----------------------------- **/

static void  fstr2cstr( const char * source, 
                        char       * target, 
                        int          slen, 
                        int          tlen )
    {
    char *bound /* JEB, ch */;
    int length ;

    for ( length = ( slen < tlen ? slen : tlen ) ,
          bound  = target + length ;
              target < bound ;
                  target++ , source++ )
        {
        *target = *source ;
        }
    
    *target = '\0' ;
    
    }       /** END Feldmanish fstr2cstr() **/


/** --------------------- cstr2fstr() ---------------------------- **/

static void  cstr2fstr( const char * source, 
                        char *       target, 
                        int          tlen )
    {
    char *bound, ch ;

    for ( bound  = target + tlen ; target < bound ; target++ , source++ )
        {
        if ( ! ( ch = *source ) ) break ;
        *target = ch ;
        }
    for ( ; target < bound ; target++ )
        {
        *target = ' ' ;
        }
    }         /** END Feldmanish cstr2fstr() **/


/** --------------------------  ENVYN()  ------------------------- **/

int ENVYN( const char * lname, 
           const char * descrip, 
           const int  * defaultval,
           int        * status,
           int          llen, 
           int          dlen )
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,   nbuff, llen, BUFLEN ) ;
    fstr2cstr( descrip, dbuff, dlen, BUFLEN ) ;

    return envync( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Feldmanish int function ENVYN() **/


/** ------------------------  ENVINT()  -------------------------- **/

int ENVINT( const char * lname, 
            const char * descrip, 
            const int  * defaultval,
            int        * status,
            int          llen, 
            int          dlen )
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,   nbuff, llen, BUFLEN ) ;
    fstr2cstr( descrip, dbuff, dlen, BUFLEN ) ;

    return envintc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Feldmanish int function ENVINT() **/


/** ------------------------  ENVREAL()  ------------------------- **/

float ENVREAL( const char  * lname, 
               const char  * descrip, 
               const float * defaultval,
               int         * status,
               int           llen, 
               int           dlen )
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname, nbuff, llen, BUFLEN ) ;
    fstr2cstr( lname, dbuff, dlen, BUFLEN ) ;

    return envrealc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Feldmanish float function ENVREAL() **/


/** -------------------------  ENVDBLE()  ------------------------ **/

double ENVDBLE( const char   * lname, 
                const char   * descrip, 
                const double * defaultval,
                int          * status,
                int            llen, 
                int            dlen )
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,   nbuff, llen, BUFLEN ) ;
    fstr2cstr( descrip, dbuff, dlen, BUFLEN ) ;

    return envdblec( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Feldmanish double function ENVDBLE() **/


/** ------------------------  ENVSTR()  -------------------------- **/

void ENVSTR( const char * lname, 
             const char * description, 
             const char * defaultval, 
             char       * eqname, 
             int        * status,
             int          namlen, 
             int          deslen, 
             int          deflen, 
             int          eqlen )
    {
    char nambuf[ BUFLEN ] ;
    char desbuf[ BUFLEN ] ;
    char defbuf[ BUFLEN ] ;
    char eqbuf [ BUFLEN ] ;

    name2cstr( lname      , nambuf, namlen, BUFLEN ) ;
    fstr2cstr( description, desbuf, deslen, BUFLEN ) ;
    fstr2cstr( defaultval , defbuf, deflen, BUFLEN ) ;
    
    envstrc( nambuf, desbuf, defbuf, eqbuf, status, eqlen ) ;
    
    cstr2fstr( eqbuf, eqname, eqlen ) ;
    
    return ;

    } /**  END Feldmanish void function ENVSTR() **/


/** ------------------------  SETENV()  -------------------------- **/

void SETENV( const char * lname, 
             const char * value, 
             int        * status,
             int          namlen, 
             int          vallen )
    {
    char putbuf[ BUFLEN ] ;   /*  construct "name=value" here */
    char /* JEB *source, */ *target /* JEB, *bound, *limit, ch */;
    int length ;

    name2cstr( lname , putbuf, namlen, BUFLEN ) ;
    length = strlen( putbuf ) ;
    target = putbuf + length ;
    *target = '=' ;
    target++ ;
    
    fstr2cstr( value, target, vallen, BUFLEN-length-1 ) ;
    
    *status = ( 0 == putenv( putbuf ) ) ;
    return ;

    } /**  END Feldmanish void function SETENV() **/


/** -------------------------------------------------------------- **/
/** END  CASE OF FELDMAN-DESCENDED F77 TARGETS FOR USE             **/
/** NEXT CASE:  WIN32-TARGETED ENV*():                         **/
/** -------------------------------------------------------------- **/

#elif  defined(_WIN32)

/** -------------------------------------------------------------- **/
/** ------------------------  auxilliary functions  -------------- **/
/** -------------------------------------------------------------- **/
/** ----------------------  name2cstr()  ------------------------- **/

static void  name2cstr( const char * source, 
                        int          slen,   /* JEB moved */
                        char       * target,
                        int          tlen )
    {
    char  *bound ;
    char   ch ;
    int    length ;
    
    tlen-- ;

    for ( length = ( slen < tlen ? slen : tlen ) ,
          bound  = target + length ;
              target < bound ;
                  target++ , source++ )
        {
        ch = *source ;
        if ( isspace( ch ) ) break ;
        *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/
    
    *target = '\0' ;
    
    }    /** END WIN32 name2cstr() **/
    

/** -------------------- fstr2cstr() ----------------------------- **/

static void  fstr2cstr( const char * source, 
                        int          slen,   /* JEB moved */
                        char       * target, 
                        int          tlen )
    {
    char *bound /* JEB, ch */;
    int length ;

    for ( length = ( slen < tlen ? slen : tlen ) ,
          bound  = target + length ;
              target < bound ;
                  target++ , source++ )
        {
        *target = *source ;
        }
    
    *target = '\0' ;
    
    }       /** END WIN32 fstr2cstr() **/


/** --------------------- cstr2fstr() ---------------------------- **/

static void  cstr2fstr( const char * source, 
                        char *       target, 
                        int          tlen )
    {
    char *bound, ch ;

    for ( bound  = target + tlen ; target < bound ; target++ , source++ )
        {
        if ( ! ( ch = *source ) ) break ;
        *target = ch ;
        }
    for ( ; target < bound ; target++ )
        {
        *target = ' ' ;
        }
    }         /** END WIN32 cstr2fstr() **/


/** --------------------------  ENVYN()  ------------------------- **/

int ENVYN( const char * lname, 
           int          llen, 
           const char * descrip, 
           int          dlen,
           const int  * defaultval,
           int        * status)
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,  llen, nbuff,  BUFLEN ) ; /* JEB moved llen */
    fstr2cstr( descrip, dlen, dbuff, BUFLEN ) ; /* JEB moved dlen */

    return envync( nbuff, dbuff, *defaultval, status ) ;

    } /**  END WIN32 int function ENVYN() **/


/** ------------------------  ENVINT()  -------------------------- **/

int ENVINT( const char * lname, 
            int          llen, 
            const char * descrip, 
            int          dlen,
            const int  * defaultval,
            int        * status)
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,  llen,  nbuff, BUFLEN ) ; /* JEB moved llen */
    fstr2cstr( descrip, dlen, dbuff, BUFLEN ) ; /* JEB moved dlen */

    return envintc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END WIN32 int function ENVINT() **/


/** ------------------------  ENVREAL()  ------------------------- **/

float ENVREAL( const char  * lname, 
               int           llen, 
               const char  * descrip, 
               int           dlen,
               const float * defaultval,
               int         * status)
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname, llen, nbuff, BUFLEN ) ; /* JEB moved llen */
    fstr2cstr( lname, dlen, dbuff, BUFLEN ) ; /* JEB moved dlen */

    return envrealc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END WIN32 float function ENVREAL() **/


/** -------------------------  ENVDBLE()  ------------------------ **/

double ENVDBLE( const char   * lname, 
                int            llen, 
                const char   * descrip, 
                int            dlen,
                const double * defaultval,
                int          * status)
    {
/* JEB    char *value ; */

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,   llen, nbuff, BUFLEN ) ; /* JEB moved llen */
    fstr2cstr( descrip, dlen, dbuff, BUFLEN ) ; /* JEB moved dlen */

    return envdblec( nbuff, dbuff, *defaultval, status ) ;

    } /**  END WIN32 double function ENVDBLE() **/


/** ------------------------  ENVSTR()  -------------------------- **/

void ENVSTR( const char * lname, 
             int          namlen, 
             const char * description, 
             int          deslen, 
             const char * defaultval, 
             int          deflen, 
             char       * eqname, 
             int          eqlen,
             int        * status)
    {
    char nambuf[ BUFLEN ] ;
    char desbuf[ BUFLEN ] ;
    char defbuf[ BUFLEN ] ;
    char eqbuf [ BUFLEN ] ;
/* JEB    char *source, *target , *bound, *limit, ch ; */
/* JEB    int length ; */

    name2cstr( lname      , namlen, nambuf, BUFLEN ) ; /* JEB moved namlen */
    fstr2cstr( description, deslen, desbuf, BUFLEN ) ; /* JEB moved deslen */
    fstr2cstr( defaultval , deflen, defbuf, BUFLEN ) ; /* JEB moved deflen */
    
    envstrc( nambuf, desbuf, defbuf, eqbuf, status, eqlen ) ;
    
    cstr2fstr( eqbuf, eqname, eqlen ) ;
    
    return ;

    } /**  END WIN32 void function ENVSTR() **/


/** -------------------------------------------------------------- **/
/** END  CASE OF WIN32 TARGETS FOR USE                             **/
/** NEXT CASE:  CRAY CF77-TARGETED ENV*():                         **/
/** -------------------------------------------------------------- **/

#elif  defined(_CRAY)

#include <fortran.h>

/** -------------------------------------------------------------- **/
/** ------------------------  auxilliary functions  -------------- **/
/** -------------------------------------------------------------- **/

static void  name2cstr( const _fcd   source, 
                        char       * target,
                        int          tlen  )
    {
    char  *bound, *ptr ;
    char   ch ;
    int    slen, length ;
    
    slen = _fcdlen( source ) ;
    tlen-- ;

    length = ( slen < tlen ? slen : tlen ) ;
    ptr    = _fcdtocp( source ) ;
    bound  = ptr + length ;
    
    for ( ; ptr < bound ; target++ , ptr++ )
        {
        if ( isspace( ch = *ptr ) ) break ;
        *target = ch ;

        } /**  END FOR-LOOP COPYING  lname  TO  buffer[], ETC.  **/

    *target = '\0' ;

    }           /** END Cray name2cstr() **/
    

/** -------------------- fstr2cstr() ----------------------------- **/

static void  fstr2cstr( const _fcd   source, 
                        char       * target, 
                        int          tlen )
    {
    char *ptr, *bound, ch ;
    int   slen, length ;

    slen = _fcdlen( source ) ;
    tlen-- ;

    length = ( slen < tlen ? slen : tlen ) ;
    ptr    = _fcdtocp( source ) ;
    for ( bound  = ptr + length ; ptr < bound ; target++ , ptr++ )
        {
        *target = *ptr ;
        }
    
    *target = '\0' ;
    
    }           /** END Cray fstr2cstr() **/


/** --------------------- cstr2fstr() ---------------------------- **/

static void  cstr2fstr( const char * source,
                        _fcd         target )
    {
    char *bound ;
    char *ptr ;
    char  ch ;
    int   length ;

    length = _fcdlen ( target ) ;
    ptr    = _fcdtocp( target ) ;
    for (  bound  = ptr + length ;  ptr < bound ;  ptr++ , source++ )
        {
        if ( !( ch = *source ) ) break ;
        *ptr = ch ;
        }
    for ( ; ptr < bound ; ptr++ )
        {
        *ptr = ' ' ;
        }
    }           /** END Cray cstr2fstr() **/


/** --------------------------  ENVYN()  ------------------------- **/

int ENVYN( const _fcd   lname, 
           const _fcd   descrip, 
           const int  * defaultval,
           int        * status )
    {
    char * getenv();
    int    in, out ;

    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname,   nbuff, BUFLEN ) ;
    fstr2cstr( descrip, dbuff, BUFLEN ) ;

    in  = _ltob( defaultval ) ;
    out = envync( nbuff, dbuff, in, status ) ;
    return _btol( out ) ;

    } /**  END Cray int function ENVYN() **/


/** ------------------------  ENVINT()  -------------------------- **/

int ENVINT( const _fcd   lname, 
            const _fcd   descrip, 
            const int  * defaultval,
            int        * status )
    {
    char *value ;
    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname  , nbuff, BUFLEN ) ;
    fstr2cstr( descrip, dbuff, BUFLEN ) ;

    return envintc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Cray int function ENVINT() **/


/** ------------------------  ENVREAL()  ------------------------- **/

float ENVREAL( const _fcd    lname, 
               const _fcd    descrip, 
               const float * defaultval,
               int         * status )
    {
    char *value ;
    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname, nbuff, BUFLEN ) ;
    fstr2cstr( lname, dbuff, BUFLEN ) ;

    return envrealc( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Cray float function ENVREAL() **/


/** -------------------------  ENVDBLE()  ------------------------ **/

double ENVDBLE( const _fcd     lname, 
                const _fcd     descrip, 
                const double * defaultval,
                int          * status )
    {
    char *value ;
    char nbuff[ BUFLEN ] ;
    char dbuff[ BUFLEN ] ;

    name2cstr( lname, nbuff, BUFLEN ) ;
    fstr2cstr( lname, dbuff, BUFLEN ) ;

    return envdblec( nbuff, dbuff, *defaultval, status ) ;

    } /**  END Cray double function ENVDBLE() **/


/** ------------------------  ENVSTR()  -------------------------- **/

void ENVSTR( const _fcd   lname, 
             const _fcd   description, 
             const _fcd   defaultval, 
             _fcd         eqname,
             int        * status )
    {
    char nambuf[ BUFLEN ] ;
    char desbuf[ BUFLEN ] ;
    char defbuf[ BUFLEN ] ;
    char eqbuf [ BUFLEN ] ;
    char *source, *target , *bound, *limit, ch ;
    int length ;

    name2cstr( lname      , nambuf, BUFLEN ) ;
    fstr2cstr( description, desbuf, BUFLEN ) ;
    fstr2cstr( defaultval , defbuf, BUFLEN ) ;
    
    envstrc( nambuf, desbuf, defbuf, eqbuf, status, BUFLEN ) ;
    
    cstr2fstr( eqbuf, eqname ) ;
    
    return ;

    } /**  END Cray void function ENVSTR() **/


/** ------------------------  SETENV()  -------------------------- **/

void SETENV( const _fcd   lname, 
             const _fcd   value, 
             int        * status )
    {
    char putbuf[ BUFLEN ] ;   /*  construct "name=value" here */
    char *source, *target , *bound, *limit, ch ;
    int length ;

    name2cstr( lname , putbuf, BUFLEN ) ;
    length = strlen( putbuf ) ;
    target = putbuf + length ;
    *target = '=' ;
    target++ ;
    fstr2cstr( value, target, BUFLEN-length-1 ) ;
    
    *status = ( 0 == putenv( putbuf ) ) ;
    return

    } /**  END Cray void function SETENV() **/



/** -------------------------------------------------------------- **/
/** END CASE OF ENV*() FOR CRAY                                    **/
/** REMAINING CASE:  UNSUPPORTED ARCHITECTURES                     **/
/** ABORT THE COMPILATION FOR THEM                                 **/
/** -------------------------------------------------------------- **/

#else

#error   "Error compiling NAMEVAL():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/
    



