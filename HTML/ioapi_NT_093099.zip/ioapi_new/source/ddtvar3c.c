/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C       Computes time derivative (per second) of specified variable "vname" 
C       from file with logical name "fname" from "buffer".
C       C wrapper around I/O API Fortran binding routine DDTVAR3().
C       
C
C PRECONDITIONS:
C       FNAME already opened by OPEN3() or open3c()
C       VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C       Fortran I/O API's DDTVAR3()
C
C REVISION HISTORY:
C       Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


                /** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && ! defined(_WIN32)   /* JEB */
#define DDTVAR3 ddtvar3_
#elif defined(__hpux) || defined(_AIX)
#define DDTVAR3 ddtvar3
#endif


#if defined(DDTVAR3)

                /** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

    extern int DDTVAR3( const char  * fname ,
                        const char  * vname ,
                        const char  * cname ,
                        int         * jdate ,
                        int         * jtime ,
                        int         * bsize ,
                        FREAL       * buffer,
                        int           fnamelen ,
                        int           vnamelen ,
                        int           cnamelen ) ;

int ddtvar3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )

    {       /*  begin body of ddtvar3c() */

    return DDTVAR3(  fname , 
                     vname , 
                     cname , 
                   & jdate , 
                   & jtime , 
                   & bsize , 
                     buffer,
                     strlen( fname ) , 
                     strlen( vname ) , 
                     strlen( cname ) ) ;

    }       /*  end body of ddtvar3c()  */

                        /** END  CASE OF FELDMAN-DESCENDED F77 TARGETS **/
                        /** NEXT CASE:  WIN32 ddtvar3c(): **/

#elif defined(_WIN32)

    extern int DDTVAR3( const char  * fname ,
                        int           fnamelen ,
                        const char  * vname ,
                        int           vnamelen ,
                        const char  * cname ,
                        int           cnamelen ,
                        int         * jdate ,
                        int         * jtime ,
                        int         * bsize ,
                        FREAL       * buffer );

int ddtvar3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )

    {       /*  begin body of ddtvar3c() */

    return DDTVAR3(  fname , 
                     strlen( fname ) , 
                     vname , 
                     strlen( vname ) ,
                     cname , 
                     strlen( cname ) ,
                   & jdate , 
                   & jtime , 
                   & bsize , 
                     buffer );

    }       /*  end body of ddtvar3c()  */

                        /** END  CASE OF WIN32 F77 TARGETS **/
                        /** NEXT CASE:  CRAY CF77-TARGETED ddtvar3c(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int DDTVAR3( const _fcd     fname ,
                        const _fcd     vname ,
                        const _fcd     cname ,
                        const  int   * jdate ,
                        const  int   * jtime ,
                        const  int   * bsize ,
                        FREAL        * buffer ) ;

int ddtvar3c( const char  * fname ,
              const char  * vname ,
              const char  * cname ,
              int           jdate ,
              int           jtime ,
              int           bsize ,
              FREAL       * buffer )
 
    {       /*  begin body of ddtvar3c() */
    
    _fcd  file ;
    _fcd  vble ;
    _fcd  caller ;
    
    file   = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble   = _cptofcd( (char *)vname, strlen( vname ) ) ;
    caller = _cptofcd( (char *)cname, strlen( cname ) ) ;

    return _btol( DDTVAR3(  file  , 
                            vble  , 
                            caller  , 
                          & jdate , 
                          & jtime ,
                          & bsize ,
                            buffer ) ) ; 
                     
    }       /*  end body of ddtvar3c ()  */

                        /** END  CASE OF CRAY CF77-TARGETED ddtvar3c(): **/

#else

#error   "Error compiling ddtvar3c():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR #IF CRAY **/

