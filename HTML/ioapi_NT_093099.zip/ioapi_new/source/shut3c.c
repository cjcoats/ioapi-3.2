/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	shut down I/O API:  C wrapper around Fortran-binding
C	routine SHUT3()
C	
C
C PRECONDITIONS:
C
C CALLS:
C	Fortran I/O API's SHUT3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "parms3.h"

#if FLDMN && !defined(_WIN32)   /* JEB */

#define SHUT3 shut3_

#elif defined(__hpux) || defined(_AIX)

#define SHUT3 shut3

#endif

		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if defined(SHUT3) || defined(_WIN32) || defined(_CRAY)

    extern int SHUT3( void ) ;

    int shut3c( void ) { 
                       return SHUT3() ; 
                       }

#else

#error   "Error compiling shut3c():  unsupported architecture"

#endif              /** IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

