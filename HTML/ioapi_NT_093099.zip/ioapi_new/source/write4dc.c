/**  
    Version "%W% %P% %G% %U%"
    EDSS/Models-3 I/O API.  Portions copyright (C) 1992-1997 MCNC
    See file "COPYRIGHT.txt" for conditions of use.
**/

/**************************************************************************
C PURPOSE:
C	Writes specified variable "vname" to file with 
C 	logical name "fname" from "buffer".
C	C wrapper around I/O API Fortran binding routine WRITE3().
C	
C
C PRECONDITIONS:
C	FNAME already opened by OPEN3() or open3c()
C	VNAME a valid variable in FNAME, or else is ALLVAR3=='ALL'
C
C CALLS:
C	Fortran I/O API's WRITE3()
C
C REVISION HISTORY:
C	Prototype 3/95 by CJC
C
**************************************************************************/

#include  <string.h>
#include  "iodecl3.h"


		/** HACKS FOR FELDMAN-DESCENDED F77'S FOLLOW: **/

#if FLDMN && !defined(_WIN32)  /* JEB */

#define WRITE4D write4d_

#elif defined(__hpux) || defined(_AIX)

#define WRITE4D write4d

#endif


#if defined(WRITE4D)

    extern int WRITE4D( const char *fname ,
                        const char *vname ,
                        int        *jdate ,
                        int        *jtime ,
                        int        *tstep ,
                        int        *nrecs ,
                        const void *buffer,
                        int         fnamelen ,
                        int         vnamelen ) ;

int write4dc( const char * fname ,
              const char * vname ,
              int          jdate ,
              int          jtime ,
              int          tstep ,
              int          nrecs ,
              const void * buffer )

    {       /*  begin body of write4dc() */

    return WRITE4D(  fname , 
                     vname , 
                   & jdate , 
                   & jtime , 
                   & tstep , 
                   & nrecs , 
                     buffer,
                     strlen( fname ) , 
                     strlen( vname ) ) ;

    }       /*  end body of write4dc ()  */

                	/** END  CASE OF FELDMAN-DESCENDED write4dc() **/
                	/** NEXT CASE:  Win32 write4dc(): **/

#elif defined(_WIN32)

    extern int WRITE4D( const char *fname ,
                        int         fnamelen ,
                        const char *vname ,
                        int         vnamelen ,
                        int        *jdate ,
                        int        *jtime ,
                        int        *tstep ,
                        int        *nrecs ,
                        const void *buffer ) ;

int write4dc( const char * fname ,
              const char * vname ,
              int          jdate ,
              int          jtime ,
              int          tstep ,
              int          nrecs ,
              const void * buffer )

    {       /*  begin body of write4dc() */

    return WRITE4D /* JEB write4d */ (  fname , 
                     strlen( fname ) , 
                     vname , 
                     strlen( vname ) ,
                   & jdate , 
                   & jtime , 
                   & tstep , 
                   & nrecs , 
                     buffer ) ;

    }       /*  end body of write4dc ()  */

                	/** END  CASE OF Win32 write4dc() **/
                	/** NEXT CASE:  CRAY CF77-TARGETED write4dc(): **/

#elif  defined(_CRAY)


#include <fortran.h>

    extern int WRITE4D( const _fcd    fname ,
                        const _fcd    vname ,
                        const  int  * jdate ,
                        const  int  * jtime ,
                        const  int  * tstep ,
                        const  int  * nrecs ,
                        const  void * buffer ) ;

int write4dc( const char  * fname ,
              const char  * vname ,
              int           jdate ,
              int           jtime ,
              int           tstep ,
              int           nrecs ,
              const void  * buffer )
 
    {       /*  begin body of write4dc() */
    
    _fcd  file ;
    _fcd  vble ;
    
    file = _cptofcd( (char *)fname, strlen( fname ) ) ;
    vble = _cptofcd( (char *)vname, strlen( vname ) ) ;

    return _btol( WRITE4D(  file , 
                            vble , 
                          & jdate, 
                          & jtime,
                          & tstep,
                          & nrecs,
                            buffer ) ) ; 
                     
    }       /*  end body of write4dc ()  */

                	/** END  CASE OF CRAY CF77-TARGETED write4dc(): **/

#else

#error   "Error compiling write4dc():  unsupported architecture"

#endif              /** #IF FELDMAN-DESCENDED F77 TARGETED, OR IF CRAY **/

